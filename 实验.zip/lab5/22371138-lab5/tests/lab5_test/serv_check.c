#include <lib.h>

void main() {
	int r1,r2;
	u_int va;
	u_int fdno;
	char buf[512];
	int n;

	r1 = open("/newmotd", O_RDONLY);
	debugf("open /newmotd: %d\n", r1);
	r2 = open("/motd", O_RDONLY);
	debugf("open /motd: %d\n", r2);

	debugf("print va of fd\n");
	for (fdno = 0; fdno < MAXFD - 1; fdno++) {
		va = INDEX2FD(fdno);
		u_int perm = vpt[VPN(va)] & 0xFFF;
		debugf("fdno: %d, va: %x, perm: %x\n", fdno, va, perm);
		if(perm & PTE_LIBRARY) {
			debugf("page of fdno %d will be shared when fork\n", fdno);
		}
	}
	debugf("print va of fd done\n");
}
