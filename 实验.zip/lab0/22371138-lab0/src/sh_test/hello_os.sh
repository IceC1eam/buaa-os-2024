#!/bin/bash
AAA=$1
BBB=$2
SCRIPT_DIR=$(dirname "$0")
sed -n '8p' $SCRIPT_DIR/$AAA > $SCRIPT_DIR/$BBB
sed -n '32p' $SCRIPT_DIR/$AAA >> $SCRIPT_DIR/$BBB
sed -n '128p' $SCRIPT_DIR/$AAA >> $SCRIPT_DIR/$BBB
sed -n '512p' $SCRIPT_DIR/$AAA >> $SCRIPT_DIR/$BBB
sed -n '1024p' $SCRIPT_DIR/$AAA >> $SCRIPT_DIR/$BBB