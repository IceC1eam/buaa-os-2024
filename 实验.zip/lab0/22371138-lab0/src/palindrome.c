#include <stdio.h>
int main()
{
	int n;
	scanf("%d", &n);
	char s[100];
	int cnt = 0;
	while (n)
	{
		s[cnt++] = n % 10;
		n /= 10;
	}
	int i = 0, j = cnt - 1;
	int flag = 1;
	while (i < j)
	{
		if (s[i] != s[j])
		{
			flag = 0;
			break;
		}
		i++;
		j--;
	}
	if (flag)
	{
		printf("Y\n");
	}
	else
	{
		printf("N\n");
	}
	return 0;
}
