#!/bin/bash

file=$1
tar=$2
res=$3

grep -n "$tar" "$file" | awk -F ':' '{print $1}' > "$res"
