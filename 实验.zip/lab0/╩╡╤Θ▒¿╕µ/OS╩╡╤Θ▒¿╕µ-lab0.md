# OS实验报告-lab0

> 学号：22371138
> 
> 姓名：贾锡冰

## 1.思考题

### 1.

执行`cat Untracked.txt`，得到结果：

```
位于分支 master

尚无提交

未跟踪的文件:
  （使用 "git add <文件>..." 以包含要提交的内容）
        REANDME.txt
        Untracked.txt

提交为空，但是存在尚未跟踪的文件（使用 "git add" 建立跟踪）
```

执行`cat Stage.txt`，得到结果：

```
位于分支 master

尚无提交

要提交的变更：
  （使用 "git rm --cached <文件>..." 以取消暂存）
        新文件：   REANDME.txt
        新文件：   Untracked.txt

未跟踪的文件:
  （使用 "git add <文件>..." 以包含要提交的内容）
        Stage.txt
```

执行`cat Modified.txt`，得到结果：

```
位于分支 master
尚未暂存以备提交的变更：
  （使用 "git add <文件>..." 更新要提交的内容）
  （使用 "git restore <文件>..." 丢弃工作区的改动）
        修改：     REANDME.txt

未跟踪的文件:
  （使用 "git add <文件>..." 以包含要提交的内容）
        Modified.txt
        Stage.txt

修改尚未加入提交（使用 "git add" 和/或 "git commit -a"）
```

执行`git add`之后，会把`README.txt`由工作区提交至暂存区。

`Modified.txt`与`Untracked.txt`不一样，因为`README.txt`在前者处于被修改状态，而其在后者处于未提交状态。

### 2.

`add the file`：git add -A

`stage the file`：git commit -m "message"

`commit`：git push

### 3.

1.

git checkout -- print.c

2.

git reset HEAD print.c

git checkout -- print.c

3.

git rm --cached hello.txt

### 4.

提交说明为3的哈希值为`8b6b2cf0f85acb961653d36c2d032bed60881bf4`；

执行`git reset --hard HEAD^`后，log中提交说明为3的提交不再显示；

执行`git reset --hard 757c4da572b61be6f8e84d7b241399d6c24621c2`后，log中提交说明为3和2的提交都不再显示；

执行 `git reset --hard 8b6b2cf0f85acb961653d36c2d032bed60881bf4`后，log中提交说明为1、2和3的提交都显示。

### 5.

执行`echo first`，在控制台输出`first`；

执行`echo second > output.txt`，`output.txt`内容为`second`；

执行`echo third > output.txt`，`output.txt`内容为`third`；

执行`echo forth >> output.txt `，`output.txt`内容为`third\nforth`。

### 6.

`command`文件内容：

```bash
echo echo Shell Start... > test
echo echo set a = 1 >> test
echo a=1 >> test
echo echo set b = 2 >> test
echo b=2 >> test
echo echo set c = a+b >> test
echo 'c=$[$a+$b]' >> test
echo 'echo c = $c' >> test
echo echo save c to ./file1 >> test
echo 'echo $c>file1' >> test
echo echo save b to ./file2 >> test
echo 'echo $b>file2' >> test
echo echo save a to ./file3 >> test
echo 'echo $a>file3' >> test
echo echo save file1 file2 file3 to file4 >> test
echo 'cat file1>file4' >> test
echo 'cat file2>>file4' >> test
echo 'cat file3>>file4' >> test
echo echo save file4 to ./result >> test
echo 'cat file4>>result' >> test
```

`test`文件内容：

```bash
echo Shell Start...
echo set a = 1
a=1
echo set b = 2
b=2
echo set c = a+b
c=$[$a+$b]
echo c = $c
echo save c to ./file1
echo $c>file1
echo save b to ./file2
echo $b>file2
echo save a to ./file3
echo $a>file3
echo save file1 file2 file3 to file4
cat file1>file4
cat file2>>file4
cat file3>>file4
echo save file4 to ./result
cat file4>>result
```

`result`文件内容：

```result
Shell Start...
set a = 1
set b = 2
set c = a+b
c = 3
save c to ./file1
save b to ./file2
save a to ./file3
save file1 file2 file3 to file4
save file4 to ./result
3
2
1
```

由于输出被重定向到result，因此所有的echo内容均被输出到result；

echo echo Shell Start会输出echo Shell Start；

echo \`echo Shell Start\`会输出Shell Start，因为反引号会直接运行其中的内容；

echo echo $c>file1会输出echo <c变量的实际值>；

echo \`echo $c>file1\`会输出<c变量的实际值>，因为反引号会直接运行其中的内容；

c的值经过计算，为3；

生成的file1储存了c的值，file2储存了b的值，file3储存了a的值；

file4储存了c、b、a的值。

## 2.难点分析

掌握Makefile的写法和格式，正确理解make工具的执行顺序和内在过程；

掌握Shell语法，掌握基本的shell编程；

学会git的使用，掌握git的多种指令，包括提交、撤回、回溯等；

学习基本的linux知识，掌握基本的linux操作指令。

## 3.实验体会

实验过程中，我学到了许多新的技术和知识，如Makefile的使用、Shell脚本编写、基本linux指令和git的使用等。这些技术的掌握不仅帮助我完成了实验任务，也丰富了我的技术栈，为我完成本学期的OS实验打下了基础。

在解决问题的过程中，我培养了逻辑思维能力。理清问题的逻辑关系、分析问题的根本原因、寻找解决方案的途径，这些都是在实验中培养的重要能力，在我未来的OS实验中必将起到重要作用。
