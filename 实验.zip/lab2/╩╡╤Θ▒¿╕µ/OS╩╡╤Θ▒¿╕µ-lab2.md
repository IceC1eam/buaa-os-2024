# OS实验报告-lab2

> 学号：22371138
> 
> 姓名：贾锡冰

## 1.思考题

### 1. 请根据上述说明，回答问题：在编写的 C 程序中，指针变量中存储的地址被视为虚拟地址，还是物理地址？MIPS 汇编程序中 lw 和 sw 指令使用的地址被视为虚拟地址，还是物理地址？

编写的 C 程序中，指针变量中存储的地址被视为虚拟地址；

MIPS 汇编程序中 lw 和 sw 指令使用的地址被视为虚拟地址。

### 2.请回答下述两个问题：

#### • 从可重用性的角度，阐述用宏来实现链表的好处。

实现了代码的模块化，方便编写、修改、维护和阅读，使用一个常用功能时无需重复编写；使用宏编写可以让链表适应通用的数据结构；减少重复代码，提高代码精简度。

#### • 查看实验环境中的 /usr/include/sys/queue.h，了解其中单向链表与循环链表的实现，比较它们与本实验中使用的双向链表，分析三者在插入与删除操作上的性能差异。

- 单向链表的结构体定义为 `SLIST_HEAD` 和 `SLIST_ENTRY`等；
- 定义了单向链表的初始化 `SLIST_INIT`，插入操作 `SLIST_INSERT_HEAD` 和 `SLIST_INSERT_AFTER`，删除操作 `SLIST_REMOVE_HEAD` 和 `SLIST_REMOVE`，以及遍历操作 `SLIST_FOREACH` 等。
- 循环链表的结构体定义为 `CIRCLEQ_HEAD` 和 `CIRCLEQ_ENTRY`等；
- 定义了循环链表的初始化 `CIRCLEQ_INIT`，插入操作 `CIRCLEQ_INSERT_HEAD`、`CIRCLEQ_INSERT_TAIL`、`CIRCLEQ_INSERT_AFTER` 和 `CIRCLEQ_INSERT_BEFORE`，删除操作 `CIRCLEQ_REMOVE`，以及遍历操作 `CIRCLEQ_FOREACH` 和 `CIRCLEQ_FOREACH_REVERSE` 等。

单向链表插入操作的时间复杂度为O(1)，删除操作的时间复杂度为O(n)，因为要通过遍历来寻找前驱节点；

双向链表插入操作的时间复杂度为O(1)，删除操作的时间复杂度也为O(1)；

循环链表与单向链表相似，插入操作的时间复杂度为O(1)，删除操作的时间复杂度为O(n)。

### 3. 请阅读 include/queue.h 以及 include/pmap.h, 将 Page_list 的结构梳 理清楚，选择正确的展开结构。

正确的展开结构为：

```c
//C选项:
struct Page_list{
struct {
struct {
struct Page *le_next;
struct Page **le_prev;
} pp_link;
u_short pp_ref;
}* lh_first;
}
```

### 4.请回答下述两个问题：

#### • 请阅读上面有关 TLB 的描述，从虚拟内存和多进程操作系统的实现角度，阐述 ASID 的必要性。

在多进程操作系统中，每个进程都有自己独立的虚拟地址空间，ASID 的存在可以确保在TLB中正确地缓存和管理不同进程的地址映射关系，有效地管理地址空间，减少 TLB 刷新的开销，并提高地址转换的效率。

#### • 请阅读 MIPS 4Kc 文档《MIPS32® 4K™ Processor Core Family Software User’s Manual》的 Section 3.3.1 与 Section 3.4，结合 ASID 段的位数，说明 4Kc 中可容纳 不同的地址空间的最大数量。

MIPS 4Kc 处理器中的 ASID 位数决定了可以支持的最大地址空间数量；4Kc的ASID 的位数为 8 位，因此最大支持的地址空间数量为 `2^8=256`个（即 2^8）。

### 5.请回答下述三个问题：

#### • tlb_invalidate 和 tlb_out 的调用关系？

```c
void tlb_invalidate(u_int asid, u_long va) {
    tlb_out((va & ~GENMASK(PGSHIFT, 0)) | (asid & (NASID - 1)));
}
```

`tlb_invalidate`调用`tlb_out`。

#### • 请用一句话概括 tlb_invalidate 的作用。

`tlb_invalidate`使指定 "asid "和虚拟地址 "va "的 TLB 条目失效，通常在操作系统内核需要刷新 TLB 时调用。

#### • 逐行解释 tlb_out 中的汇编代码。

```c
LEAF(tlb_out)
.set noreorder
    mfc0    t0, CP0_ENTRYHI //将EntryHi寄存器的内容存入寄存器t0中
    mtc0    a0, CP0_ENTRYHI //将a0中的内容写入EntryHi 寄存器
    nop //空指令
    /* Step 1: Use 'tlbp' to probe TLB entry */
    /* Exercise 2.8: Your code here. (1/2) */
    tlbp //在TLB中查找对应的表项并将其的索引存入Index寄存器
    nop //空指令
    /* Step 2: Fetch the probe result from CP0.Index */
    mfc0    t1, CP0_INDEX //将Index寄存器的内容存入t1中
.set reorder //开启指令重排序
    bltz    t1, NO_SUCH_ENTRY //如果t1小于零，则跳转到标签NO_SUCH_ENTRY处
.set noreorder //关闭指令重排序
    mtc0    zero, CP0_ENTRYHI //将EntryHi寄存器置零
    mtc0    zero, CP0_ENTRYLO0 //将EntryLo0寄存器置零
    mtc0    zero, CP0_ENTRYLO1 //将EntryLo1寄存器置零
    nop //空指令
    /* Step 3: Use 'tlbwi' to write CP0.EntryHi/Lo into TLB at CP0.Index  */
    /* Exercise 2.8: Your code here. (2/2) */
    tlbwi //将EntryHi和EntryLo写入 TLB 的指定条目中
.set reorder //开启指令重排序
```

### 6.  简单了解并叙述 X86 体系结构中的内存管理机制，比较 X86 和 MIPS 在内存管理上的区别。

![20161224201046231.png](E:\大学\OS\实验\lab2\实验报告\20161224201046231.png)

在x86架构中内存被分为三种形式，分别是**逻辑地址**（Logical Address），**线性地址**（Linear Address）和**物理地址**（Physical Address）。如上图所示，通过分段可以将逻辑地址转换为线性地址，而通过分页可以将线性地址转换为物理地址。

逻辑地址由两部分构成，一部分是段选择器（Segment Selector），一部分是偏移（Offset）。

段选择符存放在段寄存器中，如CS（存放代码段选择符）、SS（存放堆栈段选择符）、DS（存放数据段选择符）和ES、FS、GS（一般也用来存放数据段选择符）等；偏移与对应段描述符（由段选择符决定）中的基地址相加就是线性地址。

全局描述符表（Global Descriptor Table）需要OS在初始化时创建（每个CPU都有一张，基本内容大致相同，除了少数几项如TSS），创建好后将表的地址（这是个线性地址）放到全局描述符寄存器中（GDTR），这通过LGDT和SGDT指令来完成。上图只展示了全局描述符表，其实还有一种局部描述符表（Local Descriptor Table），结构与全局描述符表一致，当进程需要使用除了放在全局描述符表中的段之外的段时，就需要自己创建局部描述符表，这个用的不多。

OS需要做的就是创建全局描述符表和提供逻辑地址，之后的分段操作x86的CPU会自动完成，并找到对应的线性地址。

从线性地址到物理地址的转换也是CPU自动完成的，不过转化时使用的表（就是上图中的Page Directory和Page Table等（很多时候不只两张））也需要OS提供，对于表的创建后续也会详细介绍。

有几点需要注意：

1. 在x86架构中，分段是强制的，并不能关闭，而分页是可选的；

2. 以上是保护模式下的内存管理，在实模式下并不是这样；

3. 上述的内存管理机制通常在OS下实现，BIOS/UEFI下也不会使用（当前的UEFI应该是没有使用分页，待确定，不过可以确定的是UEFI下是可以直接访问物理地址的）；

MIPS不使用分段，而是仅使用分页进行内存管理，指令和数据存储在同一地址空间中；

MIPS 也使用页表来实现虚拟地址到物理地址的映射，但它通常使用的是两级页表结构，相比于 X86 的多级页表，MIPS 的页表结构相对简单；

MIPS不支持硬件上的虚拟内存管理，而是由操作系统负责实现虚拟内存功能。MIPS 处理器本身不具备像 X86 那样的内存管理单元（MMU），而虚拟内存管理是由操作系统的软件实现的。

## 2.难点分析

学习宏的使用，理解链表中的宏定义，学习自己写出宏；

学习二级分页式内存管理，理解分页式内存管理的核心思想，掌握页的结构，创建，修改，查询的过程；

理解TLB相关知识，对TLB的插入修改所使用的函数功能进行充分理解。

## 3.实验体会

通过编写 C 程序和 MIPS 汇编程序，我深入了解了指针、内存管理、以及 MIPS 架构下的指令集和寄存器等方面的知识。理解了虚拟地址和物理地址之间的转换过程以及 TLB 的作用，对于理解操作系统中的虚拟内存管理有了更深刻的认识。在实验第一部分中，我学会了使用宏来实现链表，提高了代码的模块化和可重用性，在二三部分实验中，我学习了MIPS分页内存管理和TLB相关知识。这次实验使我对OS的理解进一步加深。
