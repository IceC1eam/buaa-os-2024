# OS实验报告-lab4

> 学号：22371138
> 
> 姓名：贾锡冰

[toc]

## 1.思考题

### Thinking 4.1 思考并回答下面的问题：

- **内核在保存现场的时候是如何避免破坏通用寄存器的？**

系统从用户态切换到内核态后，内核首先需要将原用户进程的运行现场保存到内核空间，在`stackframe.h`中的`SAVE_ALL`宏会保存所有通用寄存器的值：

```assembly
.macro SAVE_ALL
.set noat
.set noreorder
	mfc0    k0, CP0_STATUS
	andi    k0, STATUS_UM
	beqz    k0, 1f
	move    k0, sp
	li      sp, KSTACKTOP
1:
	subu    sp, sp, TF_SIZE
	sw      k0, TF_REG29(sp)
	...省略中间部分...
	sw      $30, TF_REG30(sp)
	sw      $31, TF_REG31(sp)
.set at
.set reorder
.endm
```

在调用结束后，再使用在`stackframe.h`中的`RESTORE_ALL`宏恢复现场：

```assembly
.macro RESTORE_ALL
.set noreorder
.set noat
	lw      v0, TF_STATUS(sp)
	mtc0    v0, CP0_STATUS
	lw      v1, TF_LO(sp)
	mtlo    v1
	lw      v0, TF_HI(sp)
	lw      v1, TF_EPC(sp)
	mthi    v0
	mtc0    v1, CP0_EPC
	lw      $31, TF_REG31(sp)
	lw      $30, TF_REG30(sp)
	...省略中间部分...
	lw      $2, TF_REG2(sp)
	lw      $1, TF_REG1(sp)
	lw      sp, TF_REG29(sp)
.set at
.set reorder
.endm
```

- **系统陷入内核调用后可以直接从当时的 \$a0-\$​a3 参数寄存器中得到用户调用 msyscall 留下的信息吗？** 

可以，因为在这个过程中（如下图）， \$a0-\$a3 参数寄存器的值不会被修改。

执行系统调用的过程：![1-2](E:\大学\OS\实验\lab4\实验报告\1-2.png)

- **我们是怎么做到让 sys 开头的函数“认为”我们提供了和用户调用 msyscall 时同样的参数的？**

内核中的`sys_*`函数与用户态的`syscall_*`函数是一一对应的，而这些`syscall_*`函数都会调用`msyscall`函数。`msyscall` 一共有 6 个参数，前 4 个参数会被`syscall_*`的函数分别存入 `$a0-$a3`寄存器（寄存器传参的部分）同时栈帧底部保留 16 字节的空间（不要求存入参数的值），后 2 个参数只会被存入在预留空间之上的 8 字节空间内（没有寄存器传参），如用户态下 `$a0 `寄存器的值保存在内核栈的 `TF_REG4(sp)` 处。之后我们调用`msyscall` ，调用`handle_sys`，接着调用`do_syscall`后在 C 语言中通过` struct Trapframe * `来获取用户态现场中的参数（如下），就可以得到最开始的五个参数。

事实上，阅读MIPS调用规范可以知道，当我们MIPS中使用C语言函数调用汇编函数（或使用汇编语言函数调用C语言函数）时，都会使用以下规则：

```c
/*The Argument Section of a stack frame contains the space to store the arguments 
that are passed to any subroutine that are called by the current subroutine (i.e., the 
subroutine whose stack frame currently on top of the stack.) The first four words 
of this section are never used by the current subroutine; they are reserved for use 
by any subroutine called by the current subroutine. (Recall that up to four 
arguments can be passed to a subroutine in the argument registers ($a0 to $a3). If there are more than four arguments, the current subroutine stores them on the 
stack, at addresses sp+16, sp+20, sp+24, etc.*/

//堆栈帧的 "参数 "部分用于存储传递给当前子程序调用的任何子程序的参数（即当前堆栈帧位于堆栈顶部的子程序）。(在参数寄存器（$a0 至 $a3）中，最多可以向子程序传递四个参数。如果有四个以上的参数，当前子程序会将它们存储在堆栈中，地址分别为 sp+16、sp+20、sp+24 等。
```

![1-3](E:\大学\OS\实验\lab4\实验报告\1-3.png)

这些操作是由硬件完成的，因此我们在`syscall_*`函数中并不会看到存储寄存器和压栈的代码。

如，

```c
int syscall_mem_alloc(u_int envid, void *va, u_int perm) {
	return msyscall(SYS_mem_alloc, envid, va, perm);
}
```

`do_syscall`中取出参数（Exercise 4.2）：

```c
	func = syscall_table[sysno];

	/* Step 3: First 3 args are stored in $a1, $a2, $a3. */
	u_int arg1 = tf->regs[5];
	u_int arg2 = tf->regs[6];
	u_int arg3 = tf->regs[7];

	/* Step 4: Last 2 args are stored in stack at [$sp + 16 bytes], [$sp + 20 bytes]. */
	u_int arg4, arg5;
	/* Exercise 4.2: Your code here. (3/4) */
	arg4 = *((u_int *)(tf->regs[29]) + 4);
	arg5 = *((u_int *)(tf->regs[29]) + 5);
```

- **内核处理系统调用的过程对 Trapframe 做了哪些更改？这种修改对应的用户态的变化是什么？**

在`do_syscall`中，做了两个更改：

- - 若系统调用号不合法，则将`tf->regs[2]($v0)`改为`-E_NO_SYS`并返回，告诉用户态程序系统调用执行失败。。
  - 若系统调用合法，则将`tf->regs[2]($v0)`改为`func(arg1, arg2, arg3, arg4, arg5)`，当系统调用返回用户态时，用户态程序可以从`$v0`寄存器中读取到系统调用的结果。
- 将`tf->cp0_epc`自加4，当返回到用户态时，程序计数器将指向下一条指令，从而防止了指令的反复执行。

### Thinking 4.2 思考 envid2env 函数: 为什么 envid2env 中需要判断 e->env_id != envid 的情况？如果没有这步判断会发生什么情况？ 

要解决这个问题，我们首先需要理解`envid`的产生方式：

```c
u_int mkenvid(struct Env *e) {
	static u_int i = 0;
	return ((++i) << (1 + LOG2NENV)) | (e - envs);
}
```

而在`envid2env`函数中获取`env`控制块的方式为：

```c
e = &envs[ENVX(envid)];
```

结合以下宏定义：

```c
#define LOG2NENV 10
#define NENV (1 << LOG2NENV)
#define ENVX(envid) ((envid) & (NENV - 1))
```

我们可以知道，一个envid由两部分组成，低10位的物理位置和高22位的唯一号；

|             高22位              |       低10位       |
| :-----------------------------: | :----------------: |
| 唯一号((++i) << (1 + LOG2NENV)) | 物理位置(e - envs) |

而取出一个进程时，我们仅通过物理位置来获取它，这是不严谨的。例如一个进程在被销毁后，它的env块物理地址可能被分配给另一个进程，此时如果使用原进程号获取这个进程，如果不进行验证，就会获取到一个新进程，这会造成错误，因此需要进一步验证唯一号，以保证获取到正确的进程。

### Thinking 4.3 思考下面的问题，并对这个问题谈谈你的理解：请回顾 kern/env.c 文件中 mkenvid() 函数的实现，该函数不会返回 0，请结合系统调用和 IPC 部分的实现与 envid2env() 函数的行为进行解释。

 ```c
 u_int mkenvid(struct Env *e) {
 	static u_int i = 0;
 	return ((++i) << (1 + LOG2NENV)) | (e - envs);
 }
 ```

由于`mkenvid()`函数不会返回0，因此在`envid2env()`中，可以通过`envid == 0`判断是否为当前进程。

```c
	if (envid == 0)
	{
		*penv = curenv;
		return 0;
	}
```

而在IPC中，并没有将`envid == 0`做为一个错误判断，因为如果传入的envid为0，则`envid2env()`函数会将当前进程返回，会是当前进程与当前进程自己产生通信，并不会产生错误。

### Thinking 4.4 关于 fork 函数的两个返回值，下面说法正确的是： 

- A、fork 在父进程中被调用两次，产生两个返回值 
- B、fork 在两个进程中分别被调用一次，产生两个不同的返回值 
- C、fork 只在父进程中被调用了一次，在两个进程中各产生一个返回值 
- D、fork 只在子进程中被调用了一次，在两个进程中各产生一个返回值 

`fork()`函数的代码如下：

```c
int fork(void)
{
	u_int child;
	u_int i;

	/* Step 1: Set our TLB Mod user exception entry to 'cow_entry' if not done yet. */
	if (env->env_user_tlb_mod_entry != (u_int)cow_entry)
	{
		try(syscall_set_tlb_mod_entry(0, cow_entry));
	}

	/* Step 2: Create a child env that's not ready to be scheduled. */
	// Hint: 'env' should always point to the current env itself, so we should fix it to the
	// correct value.
	child = syscall_exofork();
	if (child == 0)
	{
		env = envs + ENVX(syscall_getenvid());
		return 0;
	}

	/* Step 3: Map all mapped pages below 'USTACKTOP' into the child's address space. */
	// Hint: You should use 'duppage'.
	/* Exercise 4.15: Your code here. (1/2) */
	for (i = 0; i < VPN(USTACKTOP); i++)
	{
		if (vpt[i] & PTE_V)
		{
			duppage(child, i);
		}
	}
	/* Step 4: Set up the child's tlb mod handler and set child's 'env_status' to
	 * 'ENV_RUNNABLE'. */
	/* Hint:
	 *   You may use 'syscall_set_tlb_mod_entry' and 'syscall_set_env_status'
	 *   Child's TLB Mod user exception entry should handle COW, so set it to 'cow_entry'
	 */
	/* Exercise 4.15: Your code here. (2/2) */
	syscall_set_tlb_mod_entry(child, cow_entry);
	syscall_set_env_status(child, ENV_RUNNABLE);

	return child;
}
```

阅读以上代码，我们可以总结fork的大致过程如下：

1. 父进程调用`syscall_set_tlb_mod_entry()`设置TLB_MOD处理函数为`copy-on-write`

2. 父进程调用`syscall_exofork()`创建子进程，此后父子进程分别运行。

3. 在子进程中：

   ```c
   	if (child == 0)
   	{
   		env = envs + ENVX(syscall_getenvid());
   		return 0;
   	}
   ```

   从`fork()`函数中返回

4. 父进程依次调用`duppage()`、`syscall_set_tlb_mod_entry()`、`syscall_set_env_status()`对子进程进行设置

5. 子进程和父进程继续正常运行

通过以上过程，我们可以发现，`fork()`只在父进程中被调用了一次，在两个进程中各产生一个返回值。

因此选择**C**选项。

### Thinking 4.5 我们并不应该对所有的用户空间页都使用 duppage 进行映射。那么究竟哪些用户空间页应该映射，哪些不应该呢？请结合 kern/env.c 中 env_init 函数进行的页面映射、include/mmu.h 里的内存布局图以及本章的后续描述进行思考。

由`mmu.h`中的内存布局图可知：

```c
/*
 o     4G ----------->  +----------------------------+------------0x100000000
 o                      |       ...                  |  kseg2
 o      KSEG2    -----> +----------------------------+------------0xc000 0000
 o                      |          Devices           |  kseg1
 o      KSEG1    -----> +----------------------------+------------0xa000 0000
 o                      |      Invalid Memory        |   /|\
 o                      +----------------------------+----|-------Physical Memory Max
 o                      |       ...                  |  kseg0
 o      KSTACKTOP-----> +----------------------------+----|-------0x8040 0000-------end
 o                      |       Kernel Stack         |    | KSTKSIZE            /|\
 o                      +----------------------------+----|------                |
 o                      |       Kernel Text          |    |                    PDMAP
 o      KERNBASE -----> +----------------------------+----|-------0x8002 0000    |
 o                      |      Exception Entry       |   \|/                    \|/
 o      ULIM     -----> +----------------------------+------------0x8000 0000-------
 o                      |         User VPT           |     PDMAP                /|\
 o      UVPT     -----> +----------------------------+------------0x7fc0 0000    |
 o                      |           pages            |     PDMAP                 |
 o      UPAGES   -----> +----------------------------+------------0x7f80 0000    |
 o                      |           envs             |     PDMAP                 |
 o  UTOP,UENVS   -----> +----------------------------+------------0x7f40 0000    |
 o  UXSTACKTOP -/       |     user exception stack   |     PTMAP                 |
 o                      +----------------------------+------------0x7f3f f000    |
 o                      |                            |     PTMAP                 |
 o      USTACKTOP ----> +----------------------------+------------0x7f3f e000    |
 o                      |     normal user stack      |     PTMAP                 |
 o                      +----------------------------+------------0x7f3f d000    |
 a                      |                            |                           |
 a                      ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                           |
 a                      .                            .                           |
 a                      .                            .                         kuseg
 a                      .                            .                           |
 a                      |~~~~~~~~~~~~~~~~~~~~~~~~~~~~|                           |
 a                      |                            |                           |
 o       UTEXT   -----> +----------------------------+------------0x0040 0000    |
 o                      |      reserved for COW      |     PTMAP                 |
 o       UCOW    -----> +----------------------------+------------0x003f f000    |
 o                      |   reversed for temporary   |     PTMAP                 |
 o       UTEMP   -----> +----------------------------+------------0x003f e000    |
 o                      |       invalid memory       |                          \|/
 a     0 ------------>  +----------------------------+ ----------------------------
 o
*/
```

`UXSTACKTOP`上的空间为系统空间，用户无权访问，不需要映射；

`UXSTACKTOP`到`UXSTACKTOP-PAGE_SIZE`为用户异常栈，用于异常处理，不映射；

`UXSTACKTOP-PAGE_SIZE`到`USTACKTOP`为空，不映射；

`USTACKTOP`到`UTEXT`之间，满足`(perm & PTE_D) && !(perm & PTE_LIBRARY) && !(perm & PTE_COW)`即可写，非共享，非写时复制的页面均需要复制。

`UTEXT`到`0`之间为无效内存和保留内存，不需要复制。

### Thinking 4.6 在遍历地址空间存取页表项时你需要使用到 vpd 和 vpt 这两个指针，请参考 user/include/lib.h 中的相关定义，思考并回答这几个问题：

- **vpt 和 vpd 的作用是什么？怎样使用它们？** 

  定义如下：

  ```c
  #define vpt ((const volatile Pte *)UVPT)
  #define vpd ((const volatile Pde *)(UVPT + (PDX(UVPT) << PGSHIFT)))
  #define UVPT (ULIM - PDMAP)
  #define PDX(va) ((((u_long)(va)) >> PDSHIFT) & 0x03FF)
  #define PDSHIFT 22
  #define PGSHIFT 12
  ```

  结合上一个thinking的内存布局图，且阅读以上宏定义可知，`vpt`为页表基地址，加上偏移量`va`即为`va`对应的页表项，可以按数组使用，如`vpt[vpn]`；`vpd`为页目录地址（由自映射计算而来），加上偏移量`va`即为`va`对应的页目录项，也可以按数组使用。

- **从实现的角度谈一下为什么进程能够通过这种方式来存取自身的页表？** 

  由env初始化过程可知：

  ```c
  /* Step 3: Map its own page table at 'UVPT' with readonly permission.
  	* As a result, user programs can read its page table through 'UVPT' */
  e->env_pgdir[PDX(UVPT)] = PADDR(e->env_pgdir) | PTE_V;
  ```

  因此，MOS 中允许在用户态下通过 `UVPT` 访问当前进程的页表和页目录。

- **它们是如何体现自映射设计的？**

  `#define vpd ((const volatile Pde *)(UVPT + (UVPT)>>10))`，可知采用了自映射机制。

- **进程能够通过这种方式来修改自己的页表项吗？**

  不能，修改页表项是内核态的操作，进程无权修改。

### Thinking 4.7 在 do_tlb_mod 函数中，你可能注意到了一个向异常处理栈复制 Trapframe 运行现场的过程，请思考并回答这几个问题：

- **这里实现了一个支持类似于“异常重入”的机制，而在什么时候会出现这种“异常重入”？**

  当在写时复制时发生缺页异常，可能再次产生缺页异常，此时会出现这种“异常重入“。

- **内核为什么需要将异常的现场 Trapframe 复制到用户空间？**

  阅读`do_tlb_mod`的代码:

  ```c
  void do_tlb_mod(struct Trapframe *tf) {
  	struct Trapframe tmp_tf = *tf;
  
  	if (tf->regs[29] < USTACKTOP || tf->regs[29] >= UXSTACKTOP) {
  		tf->regs[29] = UXSTACKTOP;
  	}
  	tf->regs[29] -= sizeof(struct Trapframe);
  	*(struct Trapframe *)tf->regs[29] = tmp_tf;
  	Pte *pte;
  	page_lookup(cur_pgdir, tf->cp0_badvaddr, &pte);
  	if (curenv->env_user_tlb_mod_entry) {
  		tf->regs[4] = tf->regs[29];
  		tf->regs[29] -= sizeof(tf->regs[4]);
  		// Hint: Set 'cp0_epc' in the context 'tf' to 'curenv->env_user_tlb_mod_entry'.
  		/* Exercise 4.11: Your code here. */
  		tf->cp0_epc = (u_long)curenv->env_user_tlb_mod_entry;
  
  	} else {
  		panic("TLB Mod but no user handler registered");
  	}
  }
  ```

  我们发现，`do_tlb_mod`是操作系统内核处理`TLB Mod exception`的函数，而MOS处理缺页异常的函数在用户态，因此这个函数将`tf`中的内容拷贝到`UXSTACK`并将`EPC`设置为用户异常处理入口，然后由用户程序处理缺页异常并恢复现场。

### Thinking 4.8 在用户态处理页写入异常，相比于在内核态处理有什么优势？ 

内核态权限较高，如果处理过程出现问题，可能对操作系统内核造成损害，还可能会产生一些安全漏洞；且在用户态处理，还能减少上下文切换，提高运行效率。

### Thinking 4.9 请思考并回答以下几个问题：

- **为什么需要将 syscall_set_tlb_mod_entry 的调用放置在 syscall_exofork 之前？**

  我们`syscall_exofork`调用了`sys_exofork`，知道阅读`sys_exofork`可知：

  ```c
  int sys_exofork(void)
  {
  	struct Env *e;
  
  	/* Step 1: Allocate a new env using 'env_alloc'. */
  	/* Exercise 4.9: Your code here. (1/4) */
  	try(env_alloc(&e, curenv->env_id));
  	/* Step 2: Copy the current Trapframe below 'KSTACKTOP' to the new env's 'env_tf'. */
  	/* Exercise 4.9: Your code here. (2/4) */
  	e->env_tf = *((struct Trapframe *)KSTACKTOP - 1);
  
  	/* Step 3: Set the new env's 'env_tf.regs[2]' to 0 to indicate the return value in child. */
  	/* Exercise 4.9: Your code here. (3/4) */
  	e->env_tf.regs[2] = 0;
  
  	/* Step 4: Set up the new env's 'env_status' and 'env_pri'.  */
  	/* Exercise 4.9: Your code here. (4/4) */
  	e->env_status = ENV_NOT_RUNNABLE;
  	e->env_pri = curenv->env_pri;
  
  	return e->env_id;
  }
  ```

  在调用`sys_exofork`时，就有可能出发缺页异常，因此需要将 `syscall_set_tlb_mod_entry` 的调用放置在 `syscall_exofork` 之前，保证在触发缺页异常后存在处理程序。

- **如果放置在写时复制保护机制完成之后会有怎样的效果？**

  会使在缺页异常触发时，没有可用的异常处理。

## 2.难点分析

本次lab主要学习了异常处理与fork，我认为这两部分都是有一定难度的。

异常处理是操作系统中确保程序稳定运行的重要机制。在学习的过程中，我逐渐理解了异常的概念、分类以及触发异常的条件。此后，我学习了本次实验的一大难点，即如何在代码中合理地设置异常处理函数，以便在程序出错时能够执行相应的异常处理。

fork是MOS系统中一个重要的系统调用，用于创建新的进程。fork的难点在于理解父进程和子进程之间的关系，以及它们之间共享和独立的资源。特别是fork过程中的数据共享，写时复制的设置和执行都很有难度。

## 3.实验体会

通过学习OS-lab4，我学习到了异常处理和fork机制在操作系统中的重要作用。这次实验不仅加深了我对操作系统原理的理解，也锻炼了我的问题解决能力。

在实验中，我遇到了不少困难，但通过查阅资料、反复调试和与同学的讨论，我逐渐克服了这些难点。特别是在处理异常和fork时，我深刻体会到了细心和耐心的重要性。只有仔细分析代码，逐步排查问题，才能找到问题的根源并解决它。

我在写`duppage`函数的时候：

```c
static void duppage(u_int envid, u_int vpn)
{
	int r;
	u_int addr;
	u_int perm;

	/* Step 1: Get the permission of the page. */
	/* Hint: Use 'vpt' to find the page table entry. */
	/* Exercise 4.10: Your code here. (1/2) */
	addr = vpn * PAGE_SIZE;
	perm = vpt[vpn] & 0xFFF;

	/* Step 2: If the page is writable, and not shared with children, and not marked as COW yet,
	 * then map it as copy-on-write, both in the parent (0) and the child (envid). */
	/* Hint: The page should be first mapped to the child before remapped in the parent. (Why?)
	 */
	/* Exercise 4.10: Your code here. (2/2) */
	if ((perm & PTE_D) && !(perm & PTE_LIBRARY) && !(perm & PTE_COW))
	{
		perm = perm & ~PTE_D;
		perm = perm | PTE_COW;
		r = syscall_mem_map(0, (void *)addr, envid, (void *)addr, perm);
		if (r < 0)
		{
			user_panic("syscall_mem_map: %e", r);
		}
		r = syscall_mem_map(0, (void *)addr, 0, (void *)addr, perm);
		if (r < 0)
		{
			user_panic("syscall_mem_map: %e", r);
		}
	}
	else
	{
		r = syscall_mem_map(0, (void *)addr, envid, (void *)addr, perm);
		if (r < 0)
		{
			user_panic("syscall_mem_map: %e", r);
		}
	}
}
```

我对`vpt`和`vpn`的使用很不理解，但通过一步一步查阅宏定义，我了解了它们的原理。在MOS操作系统中，宏的使用是非常普遍的，通过这次试验，我学会了通过查阅宏来理解MOS操作系统中的操作原理，从而帮助我更好的完成实验，理解实验。
