#ifndef _MACHINE_H_
#define _MACHINE_H_

void printcharc(char ch);
int scancharc(void);
void halt(void) __attribute__((noreturn));

#endif
