# OS实验报告-lab1

> 学号：22371138
> 
> 姓名：贾锡冰

## 1.思考题

### 1.请阅读附录中的编译链接详解，尝试分别使用实验环境中的原生 x86 工具链（gcc、ld、readelf、objdump 等）和MIPS交叉编译工具链（带有 mips-linux-gnu前缀），重复其中的编译和解析过程，观察相应的结果，并解释其中向 objdump 传入的参数的含义。

对于下面这个程序hello.c：

```c
#include <stdio.h>
int main() {
    printf("Hello, world!\n");
    return 0;
}
```

执行以下指令：

```shell
gcc -c hello.c
objdump -DS hello.o >hello.txt
cat hello.txt
```

得到以下结果：

```
hello.o：     文件格式 elf64-x86-64


Disassembly of section .text:

0000000000000000 <main>:
   0:   f3 0f 1e fa             endbr64 
   4:   55                      push   %rbp
   5:   48 89 e5                mov    %rsp,%rbp
   8:   48 8d 05 00 00 00 00    lea    0x0(%rip),%rax        # f <main+0xf>
   f:   48 89 c7                mov    %rax,%rdi
  12:   e8 00 00 00 00          call   17 <main+0x17>
  17:   b8 00 00 00 00          mov    $0x0,%eax
  1c:   5d                      pop    %rbp
  1d:   c3                      ret    

Disassembly of section .rodata:

0000000000000000 <.rodata>:
   0:   48                      rex.W
   1:   65 6c                   gs insb (%dx),%es:(%rdi)
   3:   6c                      insb   (%dx),%es:(%rdi)
   4:   6f                      outsl  %ds:(%rsi),(%dx)
   5:   2c 20                   sub    $0x20,%al
   7:   77 6f                   ja     78 <main+0x78>
   9:   72 6c                   jb     77 <main+0x77>
   b:   64 21 00                and    %eax,%fs:(%rax)

Disassembly of section .comment:

0000000000000000 <.comment>:
   0:   00 47 43                add    %al,0x43(%rdi)
   3:   43 3a 20                rex.XB cmp (%r8),%spl
   6:   28 55 62                sub    %dl,0x62(%rbp)
   9:   75 6e                   jne    79 <main+0x79>
   b:   74 75                   je     82 <main+0x82>
   d:   20 31                   and    %dh,(%rcx)
   f:   31 2e                   xor    %ebp,(%rsi)
  11:   33 2e                   xor    (%rsi),%ebp
  13:   30 2d 31 75 62 75       xor    %ch,0x75627531(%rip)        # 7562754a <main+0x7562754a>
  19:   6e                      outsb  %ds:(%rsi),(%dx)
  1a:   74 75                   je     91 <main+0x91>
  1c:   31 7e 32                xor    %edi,0x32(%rsi)
  1f:   32 2e                   xor    (%rsi),%ch
  21:   30 34 29                xor    %dh,(%rcx,%rbp,1)
  24:   20 31                   and    %dh,(%rcx)
  26:   31 2e                   xor    %ebp,(%rsi)
  28:   33 2e                   xor    (%rsi),%ebp
  2a:   30 00                   xor    %al,(%rax)

Disassembly of section .note.gnu.property:

0000000000000000 <.note.gnu.property>:
   0:   04 00                   add    $0x0,%al
   2:   00 00                   add    %al,(%rax)
   4:   10 00                   adc    %al,(%rax)
   6:   00 00                   add    %al,(%rax)
   8:   05 00 00 00 47          add    $0x47000000,%eax
   d:   4e 55                   rex.WRX push %rbp
   f:   00 02                   add    %al,(%rdx)
  11:   00 00                   add    %al,(%rax)
  13:   c0 04 00 00             rolb   $0x0,(%rax,%rax,1)
  17:   00 03                   add    %al,(%rbx)
  19:   00 00                   add    %al,(%rax)
  1b:   00 00                   add    %al,(%rax)
  1d:   00 00                   add    %al,(%rax)
        ...

Disassembly of section .eh_frame:

0000000000000000 <.eh_frame>:
   0:   14 00                   adc    $0x0,%al
   2:   00 00                   add    %al,(%rax)
   4:   00 00                   add    %al,(%rax)
   6:   00 00                   add    %al,(%rax)
   8:   01 7a 52                add    %edi,0x52(%rdx)
   b:   00 01                   add    %al,(%rcx)
   d:   78 10                   js     1f <.eh_frame+0x1f>
   f:   01 1b                   add    %ebx,(%rbx)
  11:   0c 07                   or     $0x7,%al
  13:   08 90 01 00 00 1c       or     %dl,0x1c000001(%rax)
  19:   00 00                   add    %al,(%rax)
  1b:   00 1c 00                add    %bl,(%rax,%rax,1)
  1e:   00 00                   add    %al,(%rax)
  20:   00 00                   add    %al,(%rax)
  22:   00 00                   add    %al,(%rax)
  24:   1e                      (bad)  
  25:   00 00                   add    %al,(%rax)
  27:   00 00                   add    %al,(%rax)
  29:   45 0e                   rex.RB (bad) 
  2b:   10 86 02 43 0d 06       adc    %al,0x60d4302(%rsi)
  31:   55                      push   %rbp
  32:   0c 07                   or     $0x7,%al
  34:   08 00                   or     %al,(%rax)
```

执行以下指令：

```shell
gcc -o hello hello.c
objdump -DS hello > hello.txt 
cat hello.txt 
```

得到以下结果：

```
hello：     文件格式 elf64-x86-64


Disassembly of section .interp:

0000000000000318 <.interp>:
 318:   2f                      (bad)  
 319:   6c                      insb   (%dx),%es:(%rdi)
 31a:   69 62 36 34 2f 6c 64    imul   $0x646c2f34,0x36(%rdx),%esp
 321:   2d 6c 69 6e 75          sub    $0x756e696c,%eax
 326:   78 2d                   js     355 <__abi_tag-0x37>
 328:   78 38                   js     362 <__abi_tag-0x2a>
 32a:   36 2d 36 34 2e 73       ss sub $0x732e3436,%eax
 330:   6f                      outsl  %ds:(%rsi),(%dx)
 331:   2e 32 00                cs xor (%rax),%al

Disassembly of section .note.gnu.property:

0000000000000338 <.note.gnu.property>:
 338:   04 00                   add    $0x0,%al
 33a:   00 00                   add    %al,(%rax)
 33c:   20 00                   and    %al,(%rax)
 33e:   00 00                   add    %al,(%rax)
 340:   05 00 00 00 47          add    $0x47000000,%eax
 345:   4e 55                   rex.WRX push %rbp
 347:   00 02                   add    %al,(%rdx)
 349:   00 00                   add    %al,(%rax)
 34b:   c0 04 00 00             rolb   $0x0,(%rax,%rax,1)
 34f:   00 03                   add    %al,(%rbx)
 351:   00 00                   add    %al,(%rax)
 353:   00 00                   add    %al,(%rax)
 355:   00 00                   add    %al,(%rax)
 357:   00 02                   add    %al,(%rdx)
 359:   80 00 c0                addb   $0xc0,(%rax)
 35c:   04 00                   add    $0x0,%al
 35e:   00 00                   add    %al,(%rax)
 360:   01 00                   add    %eax,(%rax)
 362:   00 00                   add    %al,(%rax)
 364:   00 00                   add    %al,(%rax)
        ...

Disassembly of section .note.gnu.build-id:

0000000000000368 <.note.gnu.build-id>:
 368:   04 00                   add    $0x0,%al
 36a:   00 00                   add    %al,(%rax)
 36c:   14 00                   adc    $0x0,%al
 36e:   00 00                   add    %al,(%rax)
 370:   03 00                   add    (%rax),%eax
 372:   00 00                   add    %al,(%rax)
 374:   47                      rex.RXB
 375:   4e 55                   rex.WRX push %rbp
 377:   00 dd                   add    %bl,%ch
 379:   cf                      iret   
 37a:   91                      xchg   %eax,%ecx
 37b:   b2 46                   mov    $0x46,%dl
 37d:   83 96 04 c7 a9 de 6b    adcl   $0x6b,-0x215638fc(%rsi)
 384:   31 c2                   xor    %eax,%edx
 386:   51                      push   %rcx
 387:   67 13 c6                addr32 adc %esi,%eax
 38a:   6b                      .byte 0x6b
 38b:   51                      push   %rcx

Disassembly of section .note.ABI-tag:

000000000000038c <__abi_tag>:
 38c:   04 00                   add    $0x0,%al
 38e:   00 00                   add    %al,(%rax)
 390:   10 00                   adc    %al,(%rax)
 392:   00 00                   add    %al,(%rax)
 394:   01 00                   add    %eax,(%rax)
 396:   00 00                   add    %al,(%rax)
 398:   47                      rex.RXB
 399:   4e 55                   rex.WRX push %rbp
 39b:   00 00                   add    %al,(%rax)
 39d:   00 00                   add    %al,(%rax)
 39f:   00 03                   add    %al,(%rbx)
 3a1:   00 00                   add    %al,(%rax)
 3a3:   00 02                   add    %al,(%rdx)
 3a5:   00 00                   add    %al,(%rax)
 3a7:   00 00                   add    %al,(%rax)
 3a9:   00 00                   add    %al,(%rax)
        ...

Disassembly of section .gnu.hash:

00000000000003b0 <.gnu.hash>:
 3b0:   02 00                   add    (%rax),%al
 3b2:   00 00                   add    %al,(%rax)
 3b4:   06                      (bad)  
 3b5:   00 00                   add    %al,(%rax)
 3b7:   00 01                   add    %al,(%rcx)
 3b9:   00 00                   add    %al,(%rax)
 3bb:   00 06                   add    %al,(%rsi)
 3bd:   00 00                   add    %al,(%rax)
 3bf:   00 00                   add    %al,(%rax)
 3c1:   00 81 00 00 00 00       add    %al,0x0(%rcx)
 3c7:   00 06                   add    %al,(%rsi)
 3c9:   00 00                   add    %al,(%rax)
 3cb:   00 00                   add    %al,(%rax)
 3cd:   00 00                   add    %al,(%rax)
 3cf:   00 d1                   add    %dl,%cl
 3d1:   65 ce                   gs (bad) 
 3d3:   6d                      insl   (%dx),%es:(%rdi)

Disassembly of section .dynsym:

00000000000003d8 <.dynsym>:
        ...
 3f0:   10 00                   adc    %al,(%rax)
 3f2:   00 00                   add    %al,(%rax)
 3f4:   12 00                   adc    (%rax),%al
        ...
 406:   00 00                   add    %al,(%rax)
 408:   48 00 00                rex.W add %al,(%rax)
 40b:   00 20                   add    %ah,(%rax)
        ...
 41d:   00 00                   add    %al,(%rax)
 41f:   00 22                   add    %ah,(%rdx)
 421:   00 00                   add    %al,(%rax)
 423:   00 12                   add    %dl,(%rdx)
        ...
 435:   00 00                   add    %al,(%rax)
 437:   00 64 00 00             add    %ah,0x0(%rax,%rax,1)
 43b:   00 20                   add    %ah,(%rax)
        ...
 44d:   00 00                   add    %al,(%rax)
 44f:   00 73 00                add    %dh,0x0(%rbx)
 452:   00 00                   add    %al,(%rax)
 454:   20 00                   and    %al,(%rax)
        ...
 466:   00 00                   add    %al,(%rax)
 468:   01 00                   add    %eax,(%rax)
 46a:   00 00                   add    %al,(%rax)
 46c:   22 00                   and    (%rax),%al
        ...

Disassembly of section .dynstr:

0000000000000480 <.dynstr>:
 480:   00 5f 5f                add    %bl,0x5f(%rdi)
 483:   63 78 61                movsxd 0x61(%rax),%edi
 486:   5f                      pop    %rdi
 487:   66 69 6e 61 6c 69       imul   $0x696c,0x61(%rsi),%bp
 48d:   7a 65                   jp     4f4 <__abi_tag+0x168>
 48f:   00 5f 5f                add    %bl,0x5f(%rdi)
 492:   6c                      insb   (%dx),%es:(%rdi)
 493:   69 62 63 5f 73 74 61    imul   $0x6174735f,0x63(%rdx),%esp
 49a:   72 74                   jb     510 <__abi_tag+0x184>
 49c:   5f                      pop    %rdi
 49d:   6d                      insl   (%dx),%es:(%rdi)
 49e:   61                      (bad)  
 49f:   69 6e 00 70 75 74 73    imul   $0x73747570,0x0(%rsi),%ebp
 4a6:   00 6c 69 62             add    %ch,0x62(%rcx,%rbp,2)
 4aa:   63 2e                   movsxd (%rsi),%ebp
 4ac:   73 6f                   jae    51d <__abi_tag+0x191>
 4ae:   2e 36 00 47 4c          cs ss add %al,0x4c(%rdi)
 4b3:   49                      rex.WB
 4b4:   42                      rex.X
 4b5:   43 5f                   rex.XB pop %r15
 4b7:   32 2e                   xor    (%rsi),%ch
 4b9:   32 2e                   xor    (%rsi),%ch
 4bb:   35 00 47 4c 49          xor    $0x494c4700,%eax
 4c0:   42                      rex.X
 4c1:   43 5f                   rex.XB pop %r15
 4c3:   32 2e                   xor    (%rsi),%ch
 4c5:   33 34 00                xor    (%rax,%rax,1),%esi
 4c8:   5f                      pop    %rdi
 4c9:   49 54                   rex.WB push %r12
 4cb:   4d 5f                   rex.WRB pop %r15
 4cd:   64 65 72 65             fs gs jb 536 <__abi_tag+0x1aa>
 4d1:   67 69 73 74 65 72 54    imul   $0x4d547265,0x74(%ebx),%esi
 4d8:   4d 
 4d9:   43 6c                   rex.XB insb (%dx),%es:(%rdi)
 4db:   6f                      outsl  %ds:(%rsi),(%dx)
 4dc:   6e                      outsb  %ds:(%rsi),(%dx)
 4dd:   65 54                   gs push %rsp
 4df:   61                      (bad)  
 4e0:   62                      (bad)  
 4e1:   6c                      insb   (%dx),%es:(%rdi)
 4e2:   65 00 5f 5f             add    %bl,%gs:0x5f(%rdi)
 4e6:   67 6d                   insl   (%dx),%es:(%edi)
 4e8:   6f                      outsl  %ds:(%rsi),(%dx)
 4e9:   6e                      outsb  %ds:(%rsi),(%dx)
 4ea:   5f                      pop    %rdi
 4eb:   73 74                   jae    561 <__abi_tag+0x1d5>
 4ed:   61                      (bad)  
 4ee:   72 74                   jb     564 <__abi_tag+0x1d8>
 4f0:   5f                      pop    %rdi
 4f1:   5f                      pop    %rdi
 4f2:   00 5f 49                add    %bl,0x49(%rdi)
 4f5:   54                      push   %rsp
 4f6:   4d 5f                   rex.WRB pop %r15
 4f8:   72 65                   jb     55f <__abi_tag+0x1d3>
 4fa:   67 69 73 74 65 72 54    imul   $0x4d547265,0x74(%ebx),%esi
 501:   4d 
 502:   43 6c                   rex.XB insb (%dx),%es:(%rdi)
 504:   6f                      outsl  %ds:(%rsi),(%dx)
 505:   6e                      outsb  %ds:(%rsi),(%dx)
 506:   65 54                   gs push %rsp
 508:   61                      (bad)  
 509:   62                      .byte 0x62
 50a:   6c                      insb   (%dx),%es:(%rdi)
 50b:   65                      gs
        ...

Disassembly of section .gnu.version:

000000000000050e <.gnu.version>:
 50e:   00 00                   add    %al,(%rax)
 510:   02 00                   add    (%rax),%al
 512:   01 00                   add    %eax,(%rax)
 514:   03 00                   add    (%rax),%eax
 516:   01 00                   add    %eax,(%rax)
 518:   01 00                   add    %eax,(%rax)
 51a:   03 00                   add    (%rax),%eax

Disassembly of section .gnu.version_r:

0000000000000520 <.gnu.version_r>:
 520:   01 00                   add    %eax,(%rax)
 522:   02 00                   add    (%rax),%al
 524:   27                      (bad)  
 525:   00 00                   add    %al,(%rax)
 527:   00 10                   add    %dl,(%rax)
 529:   00 00                   add    %al,(%rax)
 52b:   00 00                   add    %al,(%rax)
 52d:   00 00                   add    %al,(%rax)
 52f:   00 75 1a                add    %dh,0x1a(%rbp)
 532:   69 09 00 00 03 00       imul   $0x30000,(%rcx),%ecx
 538:   31 00                   xor    %eax,(%rax)
 53a:   00 00                   add    %al,(%rax)
 53c:   10 00                   adc    %al,(%rax)
 53e:   00 00                   add    %al,(%rax)
 540:   b4 91                   mov    $0x91,%ah
 542:   96                      xchg   %eax,%esi
 543:   06                      (bad)  
 544:   00 00                   add    %al,(%rax)
 546:   02 00                   add    (%rax),%al
 548:   3d 00 00 00 00          cmp    $0x0,%eax
 54d:   00 00                   add    %al,(%rax)
        ...

Disassembly of section .rela.dyn:

0000000000000550 <.rela.dyn>:
 550:   b8 3d 00 00 00          mov    $0x3d,%eax
 555:   00 00                   add    %al,(%rax)
 557:   00 08                   add    %cl,(%rax)
 559:   00 00                   add    %al,(%rax)
 55b:   00 00                   add    %al,(%rax)
 55d:   00 00                   add    %al,(%rax)
 55f:   00 40 11                add    %al,0x11(%rax)
 562:   00 00                   add    %al,(%rax)
 564:   00 00                   add    %al,(%rax)
 566:   00 00                   add    %al,(%rax)
 568:   c0 3d 00 00 00 00 00    sarb   $0x0,0x0(%rip)        # 56f <__abi_tag+0x1e3>
 56f:   00 08                   add    %cl,(%rax)
        ...
 579:   11 00                   adc    %eax,(%rax)
 57b:   00 00                   add    %al,(%rax)
 57d:   00 00                   add    %al,(%rax)
 57f:   00 08                   add    %cl,(%rax)
 581:   40 00 00                rex add %al,(%rax)
 584:   00 00                   add    %al,(%rax)
 586:   00 00                   add    %al,(%rax)
 588:   08 00                   or     %al,(%rax)
 58a:   00 00                   add    %al,(%rax)
 58c:   00 00                   add    %al,(%rax)
 58e:   00 00                   add    %al,(%rax)
 590:   08 40 00                or     %al,0x0(%rax)
 593:   00 00                   add    %al,(%rax)
 595:   00 00                   add    %al,(%rax)
 597:   00 d8                   add    %bl,%al
 599:   3f                      (bad)  
 59a:   00 00                   add    %al,(%rax)
 59c:   00 00                   add    %al,(%rax)
 59e:   00 00                   add    %al,(%rax)
 5a0:   06                      (bad)  
 5a1:   00 00                   add    %al,(%rax)
 5a3:   00 01                   add    %al,(%rcx)
        ...
 5ad:   00 00                   add    %al,(%rax)
 5af:   00 e0                   add    %ah,%al
 5b1:   3f                      (bad)  
 5b2:   00 00                   add    %al,(%rax)
 5b4:   00 00                   add    %al,(%rax)
 5b6:   00 00                   add    %al,(%rax)
 5b8:   06                      (bad)  
 5b9:   00 00                   add    %al,(%rax)
 5bb:   00 02                   add    %al,(%rdx)
        ...
 5c5:   00 00                   add    %al,(%rax)
 5c7:   00 e8                   add    %ch,%al
 5c9:   3f                      (bad)  
 5ca:   00 00                   add    %al,(%rax)
 5cc:   00 00                   add    %al,(%rax)
 5ce:   00 00                   add    %al,(%rax)
 5d0:   06                      (bad)  
 5d1:   00 00                   add    %al,(%rax)
 5d3:   00 04 00                add    %al,(%rax,%rax,1)
        ...
 5de:   00 00                   add    %al,(%rax)
 5e0:   f0 3f                   lock (bad) 
 5e2:   00 00                   add    %al,(%rax)
 5e4:   00 00                   add    %al,(%rax)
 5e6:   00 00                   add    %al,(%rax)
 5e8:   06                      (bad)  
 5e9:   00 00                   add    %al,(%rax)
 5eb:   00 05 00 00 00 00       add    %al,0x0(%rip)        # 5f1 <__abi_tag+0x265>
 5f1:   00 00                   add    %al,(%rax)
 5f3:   00 00                   add    %al,(%rax)
 5f5:   00 00                   add    %al,(%rax)
 5f7:   00 f8                   add    %bh,%al
 5f9:   3f                      (bad)  
 5fa:   00 00                   add    %al,(%rax)
 5fc:   00 00                   add    %al,(%rax)
 5fe:   00 00                   add    %al,(%rax)
 600:   06                      (bad)  
 601:   00 00                   add    %al,(%rax)
 603:   00 06                   add    %al,(%rsi)
        ...

Disassembly of section .rela.plt:

0000000000000610 <.rela.plt>:
 610:   d0 3f                   sarb   (%rdi)
 612:   00 00                   add    %al,(%rax)
 614:   00 00                   add    %al,(%rax)
 616:   00 00                   add    %al,(%rax)
 618:   07                      (bad)  
 619:   00 00                   add    %al,(%rax)
 61b:   00 03                   add    %al,(%rbx)
        ...

Disassembly of section .init:

0000000000001000 <_init>:
    1000:       f3 0f 1e fa             endbr64 
    1004:       48 83 ec 08             sub    $0x8,%rsp
    1008:       48 8b 05 d9 2f 00 00    mov    0x2fd9(%rip),%rax        # 3fe8 <__gmon_start__@Base>
    100f:       48 85 c0                test   %rax,%rax
    1012:       74 02                   je     1016 <_init+0x16>
    1014:       ff d0                   call   *%rax
    1016:       48 83 c4 08             add    $0x8,%rsp
    101a:       c3                      ret    

Disassembly of section .plt:

0000000000001020 <.plt>:
    1020:       ff 35 9a 2f 00 00       push   0x2f9a(%rip)        # 3fc0 <_GLOBAL_OFFSET_TABLE_+0x8>
    1026:       f2 ff 25 9b 2f 00 00    bnd jmp *0x2f9b(%rip)        # 3fc8 <_GLOBAL_OFFSET_TABLE_+0x10>
    102d:       0f 1f 00                nopl   (%rax)
    1030:       f3 0f 1e fa             endbr64 
    1034:       68 00 00 00 00          push   $0x0
    1039:       f2 e9 e1 ff ff ff       bnd jmp 1020 <_init+0x20>
    103f:       90                      nop

Disassembly of section .plt.got:

0000000000001040 <__cxa_finalize@plt>:
    1040:       f3 0f 1e fa             endbr64 
    1044:       f2 ff 25 ad 2f 00 00    bnd jmp *0x2fad(%rip)        # 3ff8 <__cxa_finalize@GLIBC_2.2.5>
    104b:       0f 1f 44 00 00          nopl   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

0000000000001050 <puts@plt>:
    1050:       f3 0f 1e fa             endbr64 
    1054:       f2 ff 25 75 2f 00 00    bnd jmp *0x2f75(%rip)        # 3fd0 <puts@GLIBC_2.2.5>
    105b:       0f 1f 44 00 00          nopl   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000001060 <_start>:
    1060:       f3 0f 1e fa             endbr64 
    1064:       31 ed                   xor    %ebp,%ebp
    1066:       49 89 d1                mov    %rdx,%r9
    1069:       5e                      pop    %rsi
    106a:       48 89 e2                mov    %rsp,%rdx
    106d:       48 83 e4 f0             and    $0xfffffffffffffff0,%rsp
    1071:       50                      push   %rax
    1072:       54                      push   %rsp
    1073:       45 31 c0                xor    %r8d,%r8d
    1076:       31 c9                   xor    %ecx,%ecx
    1078:       48 8d 3d ca 00 00 00    lea    0xca(%rip),%rdi        # 1149 <main>
    107f:       ff 15 53 2f 00 00       call   *0x2f53(%rip)        # 3fd8 <__libc_start_main@GLIBC_2.34>
    1085:       f4                      hlt    
    1086:       66 2e 0f 1f 84 00 00    cs nopw 0x0(%rax,%rax,1)
    108d:       00 00 00 

0000000000001090 <deregister_tm_clones>:
    1090:       48 8d 3d 79 2f 00 00    lea    0x2f79(%rip),%rdi        # 4010 <__TMC_END__>
    1097:       48 8d 05 72 2f 00 00    lea    0x2f72(%rip),%rax        # 4010 <__TMC_END__>
    109e:       48 39 f8                cmp    %rdi,%rax
    10a1:       74 15                   je     10b8 <deregister_tm_clones+0x28>
    10a3:       48 8b 05 36 2f 00 00    mov    0x2f36(%rip),%rax        # 3fe0 <_ITM_deregisterTMCloneTable@Base>
    10aa:       48 85 c0                test   %rax,%rax
    10ad:       74 09                   je     10b8 <deregister_tm_clones+0x28>
    10af:       ff e0                   jmp    *%rax
    10b1:       0f 1f 80 00 00 00 00    nopl   0x0(%rax)
    10b8:       c3                      ret    
    10b9:       0f 1f 80 00 00 00 00    nopl   0x0(%rax)

00000000000010c0 <register_tm_clones>:
    10c0:       48 8d 3d 49 2f 00 00    lea    0x2f49(%rip),%rdi        # 4010 <__TMC_END__>
    10c7:       48 8d 35 42 2f 00 00    lea    0x2f42(%rip),%rsi        # 4010 <__TMC_END__>
    10ce:       48 29 fe                sub    %rdi,%rsi
    10d1:       48 89 f0                mov    %rsi,%rax
    10d4:       48 c1 ee 3f             shr    $0x3f,%rsi
    10d8:       48 c1 f8 03             sar    $0x3,%rax
    10dc:       48 01 c6                add    %rax,%rsi
    10df:       48 d1 fe                sar    %rsi
    10e2:       74 14                   je     10f8 <register_tm_clones+0x38>
    10e4:       48 8b 05 05 2f 00 00    mov    0x2f05(%rip),%rax        # 3ff0 <_ITM_registerTMCloneTable@Base>
    10eb:       48 85 c0                test   %rax,%rax
    10ee:       74 08                   je     10f8 <register_tm_clones+0x38>
    10f0:       ff e0                   jmp    *%rax
    10f2:       66 0f 1f 44 00 00       nopw   0x0(%rax,%rax,1)
    10f8:       c3                      ret    
    10f9:       0f 1f 80 00 00 00 00    nopl   0x0(%rax)

0000000000001100 <__do_global_dtors_aux>:
    1100:       f3 0f 1e fa             endbr64 
    1104:       80 3d 05 2f 00 00 00    cmpb   $0x0,0x2f05(%rip)        # 4010 <__TMC_END__>
    110b:       75 2b                   jne    1138 <__do_global_dtors_aux+0x38>
    110d:       55                      push   %rbp
    110e:       48 83 3d e2 2e 00 00    cmpq   $0x0,0x2ee2(%rip)        # 3ff8 <__cxa_finalize@GLIBC_2.2.5>
    1115:       00 
    1116:       48 89 e5                mov    %rsp,%rbp
    1119:       74 0c                   je     1127 <__do_global_dtors_aux+0x27>
    111b:       48 8b 3d e6 2e 00 00    mov    0x2ee6(%rip),%rdi        # 4008 <__dso_handle>
    1122:       e8 19 ff ff ff          call   1040 <__cxa_finalize@plt>
    1127:       e8 64 ff ff ff          call   1090 <deregister_tm_clones>
    112c:       c6 05 dd 2e 00 00 01    movb   $0x1,0x2edd(%rip)        # 4010 <__TMC_END__>
    1133:       5d                      pop    %rbp
    1134:       c3                      ret    
    1135:       0f 1f 00                nopl   (%rax)
    1138:       c3                      ret    
    1139:       0f 1f 80 00 00 00 00    nopl   0x0(%rax)

0000000000001140 <frame_dummy>:
    1140:       f3 0f 1e fa             endbr64 
    1144:       e9 77 ff ff ff          jmp    10c0 <register_tm_clones>

0000000000001149 <main>:
    1149:       f3 0f 1e fa             endbr64 
    114d:       55                      push   %rbp
    114e:       48 89 e5                mov    %rsp,%rbp
    1151:       48 8d 05 ac 0e 00 00    lea    0xeac(%rip),%rax        # 2004 <_IO_stdin_used+0x4>
    1158:       48 89 c7                mov    %rax,%rdi
    115b:       e8 f0 fe ff ff          call   1050 <puts@plt>
    1160:       b8 00 00 00 00          mov    $0x0,%eax
    1165:       5d                      pop    %rbp
    1166:       c3                      ret    

Disassembly of section .fini:

0000000000001168 <_fini>:
    1168:       f3 0f 1e fa             endbr64 
    116c:       48 83 ec 08             sub    $0x8,%rsp
    1170:       48 83 c4 08             add    $0x8,%rsp
    1174:       c3                      ret    

Disassembly of section .rodata:

0000000000002000 <_IO_stdin_used>:
    2000:       01 00                   add    %eax,(%rax)
    2002:       02 00                   add    (%rax),%al
    2004:       48                      rex.W
    2005:       65 6c                   gs insb (%dx),%es:(%rdi)
    2007:       6c                      insb   (%dx),%es:(%rdi)
    2008:       6f                      outsl  %ds:(%rsi),(%dx)
    2009:       2c 20                   sub    $0x20,%al
    200b:       77 6f                   ja     207c <__GNU_EH_FRAME_HDR+0x68>
    200d:       72 6c                   jb     207b <__GNU_EH_FRAME_HDR+0x67>
    200f:       64 21 00                and    %eax,%fs:(%rax)

Disassembly of section .eh_frame_hdr:

0000000000002014 <__GNU_EH_FRAME_HDR>:
    2014:       01 1b                   add    %ebx,(%rbx)
    2016:       03 3b                   add    (%rbx),%edi
    2018:       30 00                   xor    %al,(%rax)
    201a:       00 00                   add    %al,(%rax)
    201c:       05 00 00 00 0c          add    $0xc000000,%eax
    2021:       f0 ff                   lock (bad) 
    2023:       ff 64 00 00             jmp    *0x0(%rax,%rax,1)
    2027:       00 2c f0                add    %ch,(%rax,%rsi,8)
    202a:       ff                      (bad)  
    202b:       ff 8c 00 00 00 3c f0    decl   -0xfc40000(%rax,%rax,1)
    2032:       ff                      (bad)  
    2033:       ff a4 00 00 00 4c f0    jmp    *-0xfb40000(%rax,%rax,1)
    203a:       ff                      (bad)  
    203b:       ff 4c 00 00             decl   0x0(%rax,%rax,1)
    203f:       00 35 f1 ff ff bc       add    %dh,-0x4300000f(%rip)        # ffffffffbd002036 <_end+0xffffffffbcffe01e>
    2045:       00 00                   add    %al,(%rax)
        ...

Disassembly of section .eh_frame:

0000000000002048 <__FRAME_END__-0xa8>:
    2048:       14 00                   adc    $0x0,%al
    204a:       00 00                   add    %al,(%rax)
    204c:       00 00                   add    %al,(%rax)
    204e:       00 00                   add    %al,(%rax)
    2050:       01 7a 52                add    %edi,0x52(%rdx)
    2053:       00 01                   add    %al,(%rcx)
    2055:       78 10                   js     2067 <__GNU_EH_FRAME_HDR+0x53>
    2057:       01 1b                   add    %ebx,(%rbx)
    2059:       0c 07                   or     $0x7,%al
    205b:       08 90 01 00 00 14       or     %dl,0x14000001(%rax)
    2061:       00 00                   add    %al,(%rax)
    2063:       00 1c 00                add    %bl,(%rax,%rax,1)
    2066:       00 00                   add    %al,(%rax)
    2068:       f8                      clc    
    2069:       ef                      out    %eax,(%dx)
    206a:       ff                      (bad)  
    206b:       ff 26                   jmp    *(%rsi)
    206d:       00 00                   add    %al,(%rax)
    206f:       00 00                   add    %al,(%rax)
    2071:       44 07                   rex.R (bad) 
    2073:       10 00                   adc    %al,(%rax)
    2075:       00 00                   add    %al,(%rax)
    2077:       00 24 00                add    %ah,(%rax,%rax,1)
    207a:       00 00                   add    %al,(%rax)
    207c:       34 00                   xor    $0x0,%al
    207e:       00 00                   add    %al,(%rax)
    2080:       a0 ef ff ff 20 00 00    movabs 0x20ffffef,%al
    2087:       00 00 
    2089:       0e                      (bad)  
    208a:       10 46 0e                adc    %al,0xe(%rsi)
    208d:       18 4a 0f                sbb    %cl,0xf(%rdx)
    2090:       0b 77 08                or     0x8(%rdi),%esi
    2093:       80 00 3f                addb   $0x3f,(%rax)
    2096:       1a 3a                   sbb    (%rdx),%bh
    2098:       2a 33                   sub    (%rbx),%dh
    209a:       24 22                   and    $0x22,%al
    209c:       00 00                   add    %al,(%rax)
    209e:       00 00                   add    %al,(%rax)
    20a0:       14 00                   adc    $0x0,%al
    20a2:       00 00                   add    %al,(%rax)
    20a4:       5c                      pop    %rsp
    20a5:       00 00                   add    %al,(%rax)
    20a7:       00 98 ef ff ff 10       add    %bl,0x10ffffef(%rax)
        ...
    20b5:       00 00                   add    %al,(%rax)
    20b7:       00 14 00                add    %dl,(%rax,%rax,1)
    20ba:       00 00                   add    %al,(%rax)
    20bc:       74 00                   je     20be <__GNU_EH_FRAME_HDR+0xaa>
    20be:       00 00                   add    %al,(%rax)
    20c0:       90                      nop
    20c1:       ef                      out    %eax,(%dx)
    20c2:       ff                      (bad)  
    20c3:       ff 10                   call   *(%rax)
        ...
    20cd:       00 00                   add    %al,(%rax)
    20cf:       00 1c 00                add    %bl,(%rax,%rax,1)
    20d2:       00 00                   add    %al,(%rax)
    20d4:       8c 00                   mov    %es,(%rax)
    20d6:       00 00                   add    %al,(%rax)
    20d8:       71 f0                   jno    20ca <__GNU_EH_FRAME_HDR+0xb6>
    20da:       ff                      (bad)  
    20db:       ff 1e                   lcall  *(%rsi)
    20dd:       00 00                   add    %al,(%rax)
    20df:       00 00                   add    %al,(%rax)
    20e1:       45 0e                   rex.RB (bad) 
    20e3:       10 86 02 43 0d 06       adc    %al,0x60d4302(%rsi)
    20e9:       55                      push   %rbp
    20ea:       0c 07                   or     $0x7,%al
    20ec:       08 00                   or     %al,(%rax)
        ...

00000000000020f0 <__FRAME_END__>:
    20f0:       00 00                   add    %al,(%rax)
        ...

Disassembly of section .init_array:

0000000000003db8 <__frame_dummy_init_array_entry>:
    3db8:       40 11 00                rex adc %eax,(%rax)
    3dbb:       00 00                   add    %al,(%rax)
    3dbd:       00 00                   add    %al,(%rax)
        ...

Disassembly of section .fini_array:

0000000000003dc0 <__do_global_dtors_aux_fini_array_entry>:
    3dc0:       00 11                   add    %dl,(%rcx)
    3dc2:       00 00                   add    %al,(%rax)
    3dc4:       00 00                   add    %al,(%rax)
        ...

Disassembly of section .dynamic:

0000000000003dc8 <_DYNAMIC>:
    3dc8:       01 00                   add    %eax,(%rax)
    3dca:       00 00                   add    %al,(%rax)
    3dcc:       00 00                   add    %al,(%rax)
    3dce:       00 00                   add    %al,(%rax)
    3dd0:       27                      (bad)  
    3dd1:       00 00                   add    %al,(%rax)
    3dd3:       00 00                   add    %al,(%rax)
    3dd5:       00 00                   add    %al,(%rax)
    3dd7:       00 0c 00                add    %cl,(%rax,%rax,1)
    3dda:       00 00                   add    %al,(%rax)
    3ddc:       00 00                   add    %al,(%rax)
    3dde:       00 00                   add    %al,(%rax)
    3de0:       00 10                   add    %dl,(%rax)
    3de2:       00 00                   add    %al,(%rax)
    3de4:       00 00                   add    %al,(%rax)
    3de6:       00 00                   add    %al,(%rax)
    3de8:       0d 00 00 00 00          or     $0x0,%eax
    3ded:       00 00                   add    %al,(%rax)
    3def:       00 68 11                add    %ch,0x11(%rax)
    3df2:       00 00                   add    %al,(%rax)
    3df4:       00 00                   add    %al,(%rax)
    3df6:       00 00                   add    %al,(%rax)
    3df8:       19 00                   sbb    %eax,(%rax)
    3dfa:       00 00                   add    %al,(%rax)
    3dfc:       00 00                   add    %al,(%rax)
    3dfe:       00 00                   add    %al,(%rax)
    3e00:       b8 3d 00 00 00          mov    $0x3d,%eax
    3e05:       00 00                   add    %al,(%rax)
    3e07:       00 1b                   add    %bl,(%rbx)
    3e09:       00 00                   add    %al,(%rax)
    3e0b:       00 00                   add    %al,(%rax)
    3e0d:       00 00                   add    %al,(%rax)
    3e0f:       00 08                   add    %cl,(%rax)
    3e11:       00 00                   add    %al,(%rax)
    3e13:       00 00                   add    %al,(%rax)
    3e15:       00 00                   add    %al,(%rax)
    3e17:       00 1a                   add    %bl,(%rdx)
    3e19:       00 00                   add    %al,(%rax)
    3e1b:       00 00                   add    %al,(%rax)
    3e1d:       00 00                   add    %al,(%rax)
    3e1f:       00 c0                   add    %al,%al
    3e21:       3d 00 00 00 00          cmp    $0x0,%eax
    3e26:       00 00                   add    %al,(%rax)
    3e28:       1c 00                   sbb    $0x0,%al
    3e2a:       00 00                   add    %al,(%rax)
    3e2c:       00 00                   add    %al,(%rax)
    3e2e:       00 00                   add    %al,(%rax)
    3e30:       08 00                   or     %al,(%rax)
    3e32:       00 00                   add    %al,(%rax)
    3e34:       00 00                   add    %al,(%rax)
    3e36:       00 00                   add    %al,(%rax)
    3e38:       f5                      cmc    
    3e39:       fe                      (bad)  
    3e3a:       ff 6f 00                ljmp   *0x0(%rdi)
    3e3d:       00 00                   add    %al,(%rax)
    3e3f:       00 b0 03 00 00 00       add    %dh,0x3(%rax)
    3e45:       00 00                   add    %al,(%rax)
    3e47:       00 05 00 00 00 00       add    %al,0x0(%rip)        # 3e4d <_DYNAMIC+0x85>
    3e4d:       00 00                   add    %al,(%rax)
    3e4f:       00 80 04 00 00 00       add    %al,0x4(%rax)
    3e55:       00 00                   add    %al,(%rax)
    3e57:       00 06                   add    %al,(%rsi)
    3e59:       00 00                   add    %al,(%rax)
    3e5b:       00 00                   add    %al,(%rax)
    3e5d:       00 00                   add    %al,(%rax)
    3e5f:       00 d8                   add    %bl,%al
    3e61:       03 00                   add    (%rax),%eax
    3e63:       00 00                   add    %al,(%rax)
    3e65:       00 00                   add    %al,(%rax)
    3e67:       00 0a                   add    %cl,(%rdx)
    3e69:       00 00                   add    %al,(%rax)
    3e6b:       00 00                   add    %al,(%rax)
    3e6d:       00 00                   add    %al,(%rax)
    3e6f:       00 8d 00 00 00 00       add    %cl,0x0(%rbp)
    3e75:       00 00                   add    %al,(%rax)
    3e77:       00 0b                   add    %cl,(%rbx)
    3e79:       00 00                   add    %al,(%rax)
    3e7b:       00 00                   add    %al,(%rax)
    3e7d:       00 00                   add    %al,(%rax)
    3e7f:       00 18                   add    %bl,(%rax)
    3e81:       00 00                   add    %al,(%rax)
    3e83:       00 00                   add    %al,(%rax)
    3e85:       00 00                   add    %al,(%rax)
    3e87:       00 15 00 00 00 00       add    %dl,0x0(%rip)        # 3e8d <_DYNAMIC+0xc5>
        ...
    3e95:       00 00                   add    %al,(%rax)
    3e97:       00 03                   add    %al,(%rbx)
    3e99:       00 00                   add    %al,(%rax)
    3e9b:       00 00                   add    %al,(%rax)
    3e9d:       00 00                   add    %al,(%rax)
    3e9f:       00 b8 3f 00 00 00       add    %bh,0x3f(%rax)
    3ea5:       00 00                   add    %al,(%rax)
    3ea7:       00 02                   add    %al,(%rdx)
    3ea9:       00 00                   add    %al,(%rax)
    3eab:       00 00                   add    %al,(%rax)
    3ead:       00 00                   add    %al,(%rax)
    3eaf:       00 18                   add    %bl,(%rax)
    3eb1:       00 00                   add    %al,(%rax)
    3eb3:       00 00                   add    %al,(%rax)
    3eb5:       00 00                   add    %al,(%rax)
    3eb7:       00 14 00                add    %dl,(%rax,%rax,1)
    3eba:       00 00                   add    %al,(%rax)
    3ebc:       00 00                   add    %al,(%rax)
    3ebe:       00 00                   add    %al,(%rax)
    3ec0:       07                      (bad)  
    3ec1:       00 00                   add    %al,(%rax)
    3ec3:       00 00                   add    %al,(%rax)
    3ec5:       00 00                   add    %al,(%rax)
    3ec7:       00 17                   add    %dl,(%rdi)
    3ec9:       00 00                   add    %al,(%rax)
    3ecb:       00 00                   add    %al,(%rax)
    3ecd:       00 00                   add    %al,(%rax)
    3ecf:       00 10                   add    %dl,(%rax)
    3ed1:       06                      (bad)  
    3ed2:       00 00                   add    %al,(%rax)
    3ed4:       00 00                   add    %al,(%rax)
    3ed6:       00 00                   add    %al,(%rax)
    3ed8:       07                      (bad)  
    3ed9:       00 00                   add    %al,(%rax)
    3edb:       00 00                   add    %al,(%rax)
    3edd:       00 00                   add    %al,(%rax)
    3edf:       00 50 05                add    %dl,0x5(%rax)
    3ee2:       00 00                   add    %al,(%rax)
    3ee4:       00 00                   add    %al,(%rax)
    3ee6:       00 00                   add    %al,(%rax)
    3ee8:       08 00                   or     %al,(%rax)
    3eea:       00 00                   add    %al,(%rax)
    3eec:       00 00                   add    %al,(%rax)
    3eee:       00 00                   add    %al,(%rax)
    3ef0:       c0 00 00                rolb   $0x0,(%rax)
    3ef3:       00 00                   add    %al,(%rax)
    3ef5:       00 00                   add    %al,(%rax)
    3ef7:       00 09                   add    %cl,(%rcx)
    3ef9:       00 00                   add    %al,(%rax)
    3efb:       00 00                   add    %al,(%rax)
    3efd:       00 00                   add    %al,(%rax)
    3eff:       00 18                   add    %bl,(%rax)
    3f01:       00 00                   add    %al,(%rax)
    3f03:       00 00                   add    %al,(%rax)
    3f05:       00 00                   add    %al,(%rax)
    3f07:       00 1e                   add    %bl,(%rsi)
    3f09:       00 00                   add    %al,(%rax)
    3f0b:       00 00                   add    %al,(%rax)
    3f0d:       00 00                   add    %al,(%rax)
    3f0f:       00 08                   add    %cl,(%rax)
    3f11:       00 00                   add    %al,(%rax)
    3f13:       00 00                   add    %al,(%rax)
    3f15:       00 00                   add    %al,(%rax)
    3f17:       00 fb                   add    %bh,%bl
    3f19:       ff                      (bad)  
    3f1a:       ff 6f 00                ljmp   *0x0(%rdi)
    3f1d:       00 00                   add    %al,(%rax)
    3f1f:       00 01                   add    %al,(%rcx)
    3f21:       00 00                   add    %al,(%rax)
    3f23:       08 00                   or     %al,(%rax)
    3f25:       00 00                   add    %al,(%rax)
    3f27:       00 fe                   add    %bh,%dh
    3f29:       ff                      (bad)  
    3f2a:       ff 6f 00                ljmp   *0x0(%rdi)
    3f2d:       00 00                   add    %al,(%rax)
    3f2f:       00 20                   add    %ah,(%rax)
    3f31:       05 00 00 00 00          add    $0x0,%eax
    3f36:       00 00                   add    %al,(%rax)
    3f38:       ff                      (bad)  
    3f39:       ff                      (bad)  
    3f3a:       ff 6f 00                ljmp   *0x0(%rdi)
    3f3d:       00 00                   add    %al,(%rax)
    3f3f:       00 01                   add    %al,(%rcx)
    3f41:       00 00                   add    %al,(%rax)
    3f43:       00 00                   add    %al,(%rax)
    3f45:       00 00                   add    %al,(%rax)
    3f47:       00 f0                   add    %dh,%al
    3f49:       ff                      (bad)  
    3f4a:       ff 6f 00                ljmp   *0x0(%rdi)
    3f4d:       00 00                   add    %al,(%rax)
    3f4f:       00 0e                   add    %cl,(%rsi)
    3f51:       05 00 00 00 00          add    $0x0,%eax
    3f56:       00 00                   add    %al,(%rax)
    3f58:       f9                      stc    
    3f59:       ff                      (bad)  
    3f5a:       ff 6f 00                ljmp   *0x0(%rdi)
    3f5d:       00 00                   add    %al,(%rax)
    3f5f:       00 03                   add    %al,(%rbx)
        ...

Disassembly of section .got:

0000000000003fb8 <_GLOBAL_OFFSET_TABLE_>:
    3fb8:       c8 3d 00 00             enter  $0x3d,$0x0
        ...
    3fd0:       30 10                   xor    %dl,(%rax)
        ...

Disassembly of section .data:

0000000000004000 <__data_start>:
        ...

0000000000004008 <__dso_handle>:
    4008:       08 40 00                or     %al,0x0(%rax)
    400b:       00 00                   add    %al,(%rax)
    400d:       00 00                   add    %al,(%rax)
        ...

Disassembly of section .bss:

0000000000004010 <completed.0>:
        ...

Disassembly of section .comment:

0000000000000000 <.comment>:
   0:   47                      rex.RXB
   1:   43                      rex.XB
   2:   43 3a 20                rex.XB cmp (%r8),%spl
   5:   28 55 62                sub    %dl,0x62(%rbp)
   8:   75 6e                   jne    78 <__abi_tag-0x314>
   a:   74 75                   je     81 <__abi_tag-0x30b>
   c:   20 31                   and    %dh,(%rcx)
   e:   31 2e                   xor    %ebp,(%rsi)
  10:   33 2e                   xor    (%rsi),%ebp
  12:   30 2d 31 75 62 75       xor    %ch,0x75627531(%rip)        # 75627549 <_end+0x75623531>
  18:   6e                      outsb  %ds:(%rsi),(%dx)
  19:   74 75                   je     90 <__abi_tag-0x2fc>
  1b:   31 7e 32                xor    %edi,0x32(%rsi)
  1e:   32 2e                   xor    (%rsi),%ch
  20:   30 34 29                xor    %dh,(%rcx,%rbp,1)
  23:   20 31                   and    %dh,(%rcx)
  25:   31 2e                   xor    %ebp,(%rsi)
  27:   33 2e                   xor    (%rsi),%ebp
  29:   30 00                   xor    %al,(%rax)
```

执行以下指令：

```shell
mips-linux-gnu-gcc -c hello.c
mips-linux-gnu-objdump -DS hello.o > hello.txt
cat hello.txt 
```

得到以下结果：

```
hello.o：     文件格式 elf32-tradbigmips


Disassembly of section .text:

00000000 <main>:
   0:   27bdffe0        addiu   sp,sp,-32
   4:   afbf001c        sw      ra,28(sp)
   8:   afbe0018        sw      s8,24(sp)
   c:   03a0f025        move    s8,sp
  10:   3c1c0000        lui     gp,0x0
  14:   279c0000        addiu   gp,gp,0
  18:   afbc0010        sw      gp,16(sp)
  1c:   3c020000        lui     v0,0x0
  20:   24440000        addiu   a0,v0,0
  24:   8f820000        lw      v0,0(gp)
  28:   0040c825        move    t9,v0
  2c:   0320f809        jalr    t9
  30:   00000000        nop
  34:   8fdc0010        lw      gp,16(s8)
  38:   00001025        move    v0,zero
  3c:   03c0e825        move    sp,s8
  40:   8fbf001c        lw      ra,28(sp)
  44:   8fbe0018        lw      s8,24(sp)
  48:   27bd0020        addiu   sp,sp,32
  4c:   03e00008        jr      ra
  50:   00000000        nop
        ...

Disassembly of section .reginfo:

00000000 <.reginfo>:
   0:   f2000014        0xf2000014
        ...

Disassembly of section .MIPS.abiflags:

00000000 <.MIPS.abiflags>:
   0:   00002002        srl     a0,zero,0x0
   4:   01010005        lsa     zero,t0,at,0x1
        ...

Disassembly of section .pdr:

00000000 <.pdr>:
   0:   00000000        nop
   4:   c0000000        ll      zero,0(zero)
   8:   fffffffc        0xfffffffc
        ...
  14:   00000020        add     zero,zero,zero
  18:   0000001e        0x1e
  1c:   0000001f        0x1f

Disassembly of section .rodata:

00000000 <.rodata>:
   0:   48656c6c        mfhc2   a1,0x6c6c
   4:   6f2c2077        0x6f2c2077
   8:   6f726c64        0x6f726c64
   c:   21000000        addi    zero,t0,0

Disassembly of section .comment:

00000000 <.comment>:
   0:   00474343        0x474343
   4:   3a202855        xori    zero,s1,0x2855
   8:   62756e74        0x62756e74
   c:   75203130        jalx    480c4c0 <main+0x480c4c0>
  10:   2e332e30        sltiu   s3,s1,11824
  14:   2d317562        sltiu   s1,t1,30050
  18:   756e7475        jalx    5b9d1d4 <main+0x5b9d1d4>
  1c:   31292031        andi    t1,t1,0x2031
  20:   302e332e        andi    t6,at,0x332e
  24:   地址 0x0000000000000024 越界。


Disassembly of section .gnu.attributes:

00000000 <.gnu.attributes>:
   0:   41000000        mftc0   zero,c0_index
   4:   0f676e75        jal     d9db9d4 <main+0xd9db9d4>
   8:   00010000        sll     zero,at,0x0
   c:   00070405        0x70405
```

执行以下指令：

```shell
mips-linux-gnu-gcc hello.c -o hello
mips-linux-gnu-objdump -DS hello > hello.txt
cat hello.txt
```

得到以下结果：

```
hello：     文件格式 elf32-tradbigmips


Disassembly of section .interp:

00400194 <.interp>:
  400194:       2f6c6962        sltiu   t4,k1,26978
  400198:       2f6c642e        sltiu   t4,k1,25646
  40019c:       736f2e31        0x736f2e31
        ...

Disassembly of section .MIPS.abiflags:

004001a8 <.MIPS.abiflags>:
  4001a8:       00002002        srl     a0,zero,0x0
  4001ac:       01010005        lsa     zero,t0,at,0x1
        ...

Disassembly of section .reginfo:

004001c0 <.reginfo>:
  4001c0:       b20000f6        0xb20000f6
        ...
  4001d4:       00419010        0x419010

Disassembly of section .note.gnu.build-id:

004001d8 <.note.gnu.build-id>:
  4001d8:       00000004        sllv    zero,zero,zero
  4001dc:       00000014        0x14
  4001e0:       00000003        sra     zero,zero,0x0
  4001e4:       474e5500        bz.w    $w14,4155e8 <_end+0x4588>
  4001e8:       83ecf9c4        lb      t4,-1596(ra)
  4001ec:       69f19457        0x69f19457
  4001f0:       a5a75ea0        sh      a3,24224(t5)
  4001f4:       24d78abf        addiu   s7,a2,-30017
  4001f8:       54add3b5        bnel    a1,t5,3f50d0 <__abi_tag-0xb12c>

Disassembly of section .note.ABI-tag:

004001fc <__abi_tag>:
  4001fc:       00000004        sllv    zero,zero,zero
  400200:       00000010        mfhi    zero
  400204:       00000001        movf    zero,zero,$fcc0
  400208:       474e5500        bz.w    $w14,41560c <_end+0x45ac>
  40020c:       00000000        nop
  400210:       00000003        sra     zero,zero,0x0
  400214:       00000002        srl     zero,zero,0x0
  400218:       00000000        nop

Disassembly of section .dynamic:

0040021c <_DYNAMIC>:
  40021c:       00000001        movf    zero,zero,$fcc0
  400220:       00000042        srl     zero,zero,0x1
  400224:       0000000c        syscall
  400228:       004004c4        0x4004c4
  40022c:       0000000d        break
  400230:       004007d0        0x4007d0
  400234:       00000004        sllv    zero,zero,zero
  400238:       004002fc        0x4002fc
  40023c:       00000005        lsa     zero,zero,zero,0x1
  400240:       004003d8        0x4003d8
  400244:       00000006        srlv    zero,zero,zero
  400248:       00400338        0x400338
  40024c:       0000000a        movz    zero,zero,zero
  400250:       000000a6        0xa6
  400254:       0000000b        movn    zero,zero,zero
  400258:       00000010        mfhi    zero
  40025c:       70000016        udi6    zero,zero,zero,0x0
  400260:       00411010        0x411010
  400264:       70000035        0x70000035
  400268:       00010dac        0x10dac
  40026c:       00000015        0x15
  400270:       00000000        nop
  400274:       00000003        sra     zero,zero,0x0
  400278:       00411020        add     v0,v0,at
  40027c:       70000001        maddu   zero,zero
  400280:       00000001        movf    zero,zero,$fcc0
  400284:       70000005        msubu   zero,zero
  400288:       00000002        srl     zero,zero,0x0
  40028c:       70000006        0x70000006
  400290:       00400000        0x400000
  400294:       7000000a        0x7000000a
  400298:       00000006        srlv    zero,zero,zero
  40029c:       70000011        udi1    zero,zero,zero,0x0
  4002a0:       0000000a        movz    zero,zero,zero
  4002a4:       70000012        udi2    zero,zero,zero,0x0
  4002a8:       0000001d        0x1d
  4002ac:       70000013        udi3    zero,zero,zero,0x0
  4002b0:       00000005        lsa     zero,zero,zero,0x1
  4002b4:       6ffffffe        0x6ffffffe
  4002b8:       00400494        0x400494
  4002bc:       6fffffff        0x6fffffff
  4002c0:       00000001        movf    zero,zero,$fcc0
  4002c4:       6ffffff0        0x6ffffff0
  4002c8:       0040047e        0x40047e
        ...

Disassembly of section .hash:

004002fc <.hash>:
  4002fc:       00000003        sra     zero,zero,0x0
  400300:       0000000a        movz    zero,zero,zero
  400304:       00000006        srlv    zero,zero,zero
  400308:       00000005        lsa     zero,zero,zero,0x1
  40030c:       00000003        sra     zero,zero,0x0
  400310:       00000000        nop
  400314:       00000009        jalr    zero,zero
  400318:       00000000        nop
  40031c:       00000002        srl     zero,zero,0x0
  400320:       00000007        srav    zero,zero,zero
  400324:       00000004        sllv    zero,zero,zero
  400328:       00000000        nop
  40032c:       00000008        jr      zero
  400330:       00000001        movf    zero,zero,$fcc0
  400334:       00000000        nop

Disassembly of section .dynsym:

00400338 <.dynsym>:
        ...
  400348:       00000013        mtlo    zero
  40034c:       00000001        movf    zero,zero,$fcc0
  400350:       00000000        nop
  400354:       1300fff1        beqz    t8,40031c <_DYNAMIC+0x100>
  400358:       00000033        tltu    zero,zero
  40035c:       00400820        add     at,v0,zero
  400360:       00000004        sllv    zero,zero,zero
  400364:       11000010        beqz    t0,4003a8 <_DYNAMIC+0x18c>
  400368:       00000024        and     zero,zero,zero
  40036c:       00411010        0x411010
  400370:       00000000        nop
  400374:       11000015        beqz    t0,4003cc <_DYNAMIC+0x1b0>
  400378:       0000000e        0xe
  40037c:       004006e0        0x4006e0
  400380:       00000054        0x54
  400384:       1200000d        beqz    s0,4003bc <_DYNAMIC+0x1a0>
  400388:       00000077        0x77
        ...
  400394:       20000000        addi    zero,zero,0
  400398:       0000004c        syscall 0x1
        ...
  4003a4:       22000000        addi    zero,s0,0
  4003a8:       0000002e        0x2e
  4003ac:       004007b0        tge     v0,zero,0x1e
  4003b0:       00000000        nop
  4003b4:       12000000        beqz    s0,4003b8 <_DYNAMIC+0x19c>
  4003b8:       0000005b        0x5b
        ...
  4003c4:       20000000        addi    zero,zero,0
  4003c8:       00000001        movf    zero,zero,$fcc0
  4003cc:       004007a0        0x4007a0
  4003d0:       00000000        nop
  4003d4:       12000000        beqz    s0,4003d8 <_DYNAMIC+0x1bc>

Disassembly of section .dynstr:

004003d8 <.dynstr>:
  4003d8:       005f5f6c        0x5f5f6c
  4003dc:       6962635f        0x6962635f
  4003e0:       73746172        0x73746172
  4003e4:       745f6d61        jalx    17db584 <_gp+0x13c2574>
  4003e8:       696e005f        0x696e005f
  4003ec:       44594e41        0x44594e41
  4003f0:       4d49435f        0x4d49435f
  4003f4:       4c494e4b        0x4c494e4b
  4003f8:       494e4700        0x494e4700
  4003fc:       5f5f524c        0x5f5f524c
  400400:       445f4d41        0x445f4d41
  400404:       50007075        beqzl   zero,41c5dc <_gp+0x35cc>
  400408:       7473005f        jalx    1cc017c <_gp+0x18a716c>
  40040c:       494f5f73        0x494f5f73
  400410:       7464696e        jalx    191a5b8 <_gp+0x15015a8>
  400414:       5f757365        0x5f757365
  400418:       64006c69        0x64006c69
  40041c:       62632e73        0x62632e73
  400420:       6f2e3600        0x6f2e3600
  400424:       5f5f676d        0x5f5f676d
  400428:       6f6e5f73        0x6f6e5f73
  40042c:       74617274        jalx    185c9d0 <_gp+0x14439c0>
  400430:       5f5f005f        0x5f5f005f
  400434:       49544d5f        0x49544d5f
  400438:       64657265        0x64657265
  40043c:       67697374        0x67697374
  400440:       6572544d        0x6572544d
  400444:       436c6f6e        c0      0x16c6f6e
  400448:       65546162        0x65546162
  40044c:       6c65005f        0x6c65005f
  400450:       49544d5f        0x49544d5f
  400454:       72656769        0x72656769
  400458:       73746572        0x73746572
  40045c:       544d436c        bnel    v0,t5,411210 <_end+0x1b0>
  400460:       6f6e6554        0x6f6e6554
  400464:       61626c65        0x61626c65
  400468:       00474c49        0x474c49
  40046c:       42435f32        c0      0x435f32
  400470:       2e300047        sltiu   s0,s1,71
  400474:       4c494243        0x4c494243
  400478:       5f322e33        0x5f322e33
  40047c:       地址 0x000000000040047c 越界。


Disassembly of section .gnu.version:

0040047e <.gnu.version>:
  40047e:       00000001        movf    zero,zero,$fcc0
  400482:       00010001        movt    zero,zero,$fcc0
  400486:       00010001        movt    zero,zero,$fcc0
  40048a:       00010003        sra     zero,at,0x0
  40048e:       00010002        srl     zero,at,0x0

Disassembly of section .gnu.version_r:

00400494 <.gnu.version_r>:
  400494:       00010002        srl     zero,at,0x0
  400498:       00000042        srl     zero,zero,0x1
  40049c:       00000010        mfhi    zero
  4004a0:       00000000        nop
  4004a4:       0d696910        jal     5a5a440 <_gp+0x5641430>
  4004a8:       00000003        sra     zero,zero,0x0
  4004ac:       00000091        0x91
  4004b0:       00000010        mfhi    zero
  4004b4:       069691b4        0x69691b4
  4004b8:       00000002        srl     zero,zero,0x0
  4004bc:       0000009b        0x9b
  4004c0:       00000000        nop

Disassembly of section .init:

004004c4 <_init>:
  4004c4:       3c1c0002        lui     gp,0x2
  4004c8:       279c8b4c        addiu   gp,gp,-29876
  4004cc:       0399e021        addu    gp,gp,t9
  4004d0:       27bdffe0        addiu   sp,sp,-32
  4004d4:       afbc0010        sw      gp,16(sp)
  4004d8:       afbf001c        sw      ra,28(sp)
  4004dc:       8f82802c        lw      v0,-32724(gp)
  4004e0:       10400004        beqz    v0,4004f4 <_init+0x30>
  4004e4:       00000000        nop
  4004e8:       8f99802c        lw      t9,-32724(gp)
  4004ec:       0320f809        jalr    t9
  4004f0:       00000000        nop
  4004f4:       04110001        bal     4004fc <_init+0x38>
  4004f8:       00000000        nop
  4004fc:       3c1c0042        lui     gp,0x42
  400500:       279c9010        addiu   gp,gp,-28656
  400504:       8f99801c        lw      t9,-32740(gp)
  400508:       273906d4        addiu   t9,t9,1748
  40050c:       0320f809        jalr    t9
  400510:       00000000        nop
  400514:       04110001        bal     40051c <_init+0x58>
  400518:       00000000        nop
  40051c:       3c1c0042        lui     gp,0x42
  400520:       279c9010        addiu   gp,gp,-28656
  400524:       8f99801c        lw      t9,-32740(gp)
  400528:       27390740        addiu   t9,t9,1856
  40052c:       0320f809        jalr    t9
  400530:       00000000        nop
  400534:       8fbf001c        lw      ra,28(sp)
  400538:       03e00008        jr      ra
  40053c:       27bd0020        addiu   sp,sp,32

Disassembly of section .text:

00400540 <__start>:
  400540:       03e00025        move    zero,ra
  400544:       04110001        bal     40054c <__start+0xc>
  400548:       00000000        nop
  40054c:       3c1c0002        lui     gp,0x2
  400550:       279c8ac4        addiu   gp,gp,-30012
  400554:       039fe021        addu    gp,gp,ra
  400558:       0000f825        move    ra,zero
  40055c:       8f848018        lw      a0,-32744(gp)
  400560:       8fa50000        lw      a1,0(sp)
  400564:       27a60004        addiu   a2,sp,4
  400568:       2401fff8        li      at,-8
  40056c:       03a1e824        and     sp,sp,at
  400570:       27bdffe0        addiu   sp,sp,-32
  400574:       00003825        move    a3,zero
  400578:       afa00010        sw      zero,16(sp)
  40057c:       afa20014        sw      v0,20(sp)
  400580:       afbd0018        sw      sp,24(sp)
  400584:       8f998038        lw      t9,-32712(gp)
  400588:       0320f809        jalr    t9
  40058c:       00000000        nop

00400590 <hlt>:
  400590:       1000ffff        b       400590 <hlt>
  400594:       00000000        nop
        ...

004005a0 <deregister_tm_clones>:
  4005a0:       3c040041        lui     a0,0x41
  4005a4:       3c020041        lui     v0,0x41
  4005a8:       24841014        addiu   a0,a0,4116
  4005ac:       24421014        addiu   v0,v0,4116
  4005b0:       10440007        beq     v0,a0,4005d0 <deregister_tm_clones+0x30>
  4005b4:       3c1c0042        lui     gp,0x42
  4005b8:       279c9010        addiu   gp,gp,-28656
  4005bc:       8f998034        lw      t9,-32716(gp)
  4005c0:       13200003        beqz    t9,4005d0 <deregister_tm_clones+0x30>
  4005c4:       00000000        nop
  4005c8:       03200008        jr      t9
  4005cc:       00000000        nop
  4005d0:       03e00008        jr      ra
  4005d4:       00000000        nop

004005d8 <register_tm_clones>:
  4005d8:       3c040041        lui     a0,0x41
  4005dc:       3c020041        lui     v0,0x41
  4005e0:       24841014        addiu   a0,a0,4116
  4005e4:       24451014        addiu   a1,v0,4116
  4005e8:       00a42823        subu    a1,a1,a0
  4005ec:       00051083        sra     v0,a1,0x2
  4005f0:       00052fc2        srl     a1,a1,0x1f
  4005f4:       00a22821        addu    a1,a1,v0
  4005f8:       00052843        sra     a1,a1,0x1
  4005fc:       10a00007        beqz    a1,40061c <register_tm_clones+0x44>
  400600:       3c1c0042        lui     gp,0x42
  400604:       279c9010        addiu   gp,gp,-28656
  400608:       8f998028        lw      t9,-32728(gp)
  40060c:       13200003        beqz    t9,40061c <register_tm_clones+0x44>
  400610:       00000000        nop
  400614:       03200008        jr      t9
  400618:       00000000        nop
  40061c:       03e00008        jr      ra
  400620:       00000000        nop

00400624 <__do_global_dtors_aux>:
  400624:       27bdffd0        addiu   sp,sp,-48
  400628:       afb30028        sw      s3,40(sp)
  40062c:       3c130041        lui     s3,0x41
  400630:       afbf002c        sw      ra,44(sp)
  400634:       afb20024        sw      s2,36(sp)
  400638:       afb10020        sw      s1,32(sp)
  40063c:       afb0001c        sw      s0,28(sp)
  400640:       92621050        lbu     v0,4176(s3)
  400644:       1440001c        bnez    v0,4006b8 <__do_global_dtors_aux+0x94>
  400648:       3c110041        lui     s1,0x41
  40064c:       3c020041        lui     v0,0x41
  400650:       26310ffc        addiu   s1,s1,4092
  400654:       24420ff8        addiu   v0,v0,4088
  400658:       3c100041        lui     s0,0x41
  40065c:       02228823        subu    s1,s1,v0
  400660:       3c020041        lui     v0,0x41
  400664:       00118883        sra     s1,s1,0x2
  400668:       24520ff8        addiu   s2,v0,4088
  40066c:       8e021054        lw      v0,4180(s0)
  400670:       2631ffff        addiu   s1,s1,-1
  400674:       0051182b        sltu    v1,v0,s1
  400678:       1060000b        beqz    v1,4006a8 <__do_global_dtors_aux+0x84>
  40067c:       24420001        addiu   v0,v0,1
  400680:       00021880        sll     v1,v0,0x2
  400684:       ae021054        sw      v0,4180(s0)
  400688:       02431021        addu    v0,s2,v1
  40068c:       8c590000        lw      t9,0(v0)
  400690:       0320f809        jalr    t9
  400694:       00000000        nop
  400698:       8e021054        lw      v0,4180(s0)
  40069c:       0051182b        sltu    v1,v0,s1
  4006a0:       1460fff7        bnez    v1,400680 <__do_global_dtors_aux+0x5c>
  4006a4:       24420001        addiu   v0,v0,1
  4006a8:       0c100168        jal     4005a0 <deregister_tm_clones>
  4006ac:       00000000        nop
  4006b0:       24020001        li      v0,1
  4006b4:       a2621050        sb      v0,4176(s3)
  4006b8:       8fbf002c        lw      ra,44(sp)
  4006bc:       8fb30028        lw      s3,40(sp)
  4006c0:       8fb20024        lw      s2,36(sp)
  4006c4:       8fb10020        lw      s1,32(sp)
  4006c8:       8fb0001c        lw      s0,28(sp)
  4006cc:       03e00008        jr      ra
  4006d0:       27bd0030        addiu   sp,sp,48

004006d4 <frame_dummy>:
  4006d4:       08100176        j       4005d8 <register_tm_clones>
  4006d8:       00000000        nop
  4006dc:       00000000        nop

004006e0 <main>:
  4006e0:       27bdffe0        addiu   sp,sp,-32
  4006e4:       afbf001c        sw      ra,28(sp)
  4006e8:       afbe0018        sw      s8,24(sp)
  4006ec:       03a0f025        move    s8,sp
  4006f0:       3c1c0042        lui     gp,0x42
  4006f4:       279c9010        addiu   gp,gp,-28656
  4006f8:       afbc0010        sw      gp,16(sp)
  4006fc:       3c020040        lui     v0,0x40
  400700:       24440830        addiu   a0,v0,2096
  400704:       8f828030        lw      v0,-32720(gp)
  400708:       0040c825        move    t9,v0
  40070c:       0320f809        jalr    t9
  400710:       00000000        nop
  400714:       8fdc0010        lw      gp,16(s8)
  400718:       00001025        move    v0,zero
  40071c:       03c0e825        move    sp,s8
  400720:       8fbf001c        lw      ra,28(sp)
  400724:       8fbe0018        lw      s8,24(sp)
  400728:       27bd0020        addiu   sp,sp,32
  40072c:       03e00008        jr      ra
  400730:       00000000        nop
        ...

00400740 <__do_global_ctors_aux>:
  400740:       3c030041        lui     v1,0x41
  400744:       2402ffff        li      v0,-1
  400748:       8c790ff0        lw      t9,4080(v1)
  40074c:       13220010        beq     t9,v0,400790 <__do_global_ctors_aux+0x50>
  400750:       00000000        nop
  400754:       27bdffd8        addiu   sp,sp,-40
  400758:       afb10020        sw      s1,32(sp)
  40075c:       2411ffff        li      s1,-1
  400760:       afb0001c        sw      s0,28(sp)
  400764:       24700ff0        addiu   s0,v1,4080
  400768:       afbf0024        sw      ra,36(sp)
  40076c:       0320f809        jalr    t9
  400770:       2610fffc        addiu   s0,s0,-4
  400774:       8e190000        lw      t9,0(s0)
  400778:       1731fffc        bne     t9,s1,40076c <__do_global_ctors_aux+0x2c>
  40077c:       8fbf0024        lw      ra,36(sp)
  400780:       8fb10020        lw      s1,32(sp)
  400784:       8fb0001c        lw      s0,28(sp)
  400788:       03e00008        jr      ra
  40078c:       27bd0028        addiu   sp,sp,40
  400790:       03e00008        jr      ra
  400794:       00000000        nop
        ...

Disassembly of section .MIPS.stubs:

004007a0 <_MIPS_STUBS_>:
  4007a0:       8f998010        lw      t9,-32752(gp)
  4007a4:       03e07825        move    t7,ra
  4007a8:       0320f809        jalr    t9
  4007ac:       24180009        li      t8,9
  4007b0:       8f998010        lw      t9,-32752(gp)
  4007b4:       03e07825        move    t7,ra
  4007b8:       0320f809        jalr    t9
  4007bc:       24180007        li      t8,7
        ...

Disassembly of section .fini:

004007d0 <_fini>:
  4007d0:       3c1c0002        lui     gp,0x2
  4007d4:       279c8840        addiu   gp,gp,-30656
  4007d8:       0399e021        addu    gp,gp,t9
  4007dc:       27bdffe0        addiu   sp,sp,-32
  4007e0:       afbc0010        sw      gp,16(sp)
  4007e4:       afbf001c        sw      ra,28(sp)
  4007e8:       04110001        bal     4007f0 <_fini+0x20>
  4007ec:       00000000        nop
  4007f0:       3c1c0042        lui     gp,0x42
  4007f4:       279c9010        addiu   gp,gp,-28656
  4007f8:       8f99801c        lw      t9,-32740(gp)
  4007fc:       27390624        addiu   t9,t9,1572
  400800:       0320f809        jalr    t9
  400804:       00000000        nop
  400808:       8fbf001c        lw      ra,28(sp)
  40080c:       03e00008        jr      ra
  400810:       27bd0020        addiu   sp,sp,32

Disassembly of section .rodata:

00400820 <_IO_stdin_used>:
  400820:       00020001        0x20001
        ...
  400830:       48656c6c        mfhc2   a1,0x6c6c
  400834:       6f2c2077        0x6f2c2077
  400838:       6f726c64        0x6f726c64
  40083c:       21000000        addi    zero,t0,0

Disassembly of section .eh_frame:

00400840 <__FRAME_END__>:
  400840:       00000000        nop

Disassembly of section .ctors:

00410ff0 <__CTOR_LIST__>:
  410ff0:       ffffffff        0xffffffff

00410ff4 <__CTOR_END__>:
  410ff4:       00000000        nop

Disassembly of section .dtors:

00410ff8 <__DTOR_LIST__>:
  410ff8:       ffffffff        0xffffffff

00410ffc <__DTOR_END__>:
  410ffc:       00000000        nop

Disassembly of section .data:

00411000 <__data_start>:
        ...

Disassembly of section .rld_map:

00411010 <__RLD_MAP>:
  411010:       00000000        nop

Disassembly of section .got:

00411020 <_GLOBAL_OFFSET_TABLE_>:
  411020:       00000000        nop
  411024:       80000000        lb      zero,0(zero)
  411028:       004006e0        0x4006e0
  41102c:       00400000        0x400000
        ...
  411040:       004007b0        tge     v0,zero,0x1e
  411044:       00000000        nop
  411048:       004007a0        0x4007a0

Disassembly of section .sdata:

0041104c <__dso_handle>:
  41104c:       00000000        nop

Disassembly of section .bss:

00411050 <completed.1>:
  411050:       00000000        nop

00411054 <dtor_idx.0>:
        ...

Disassembly of section .comment:

00000000 <.comment>:
   0:   4743433a        bz.w    $w3,10cec <__abi_tag-0x3ef510>
   4:   20285562        addi    t0,at,21858
   8:   756e7475        jalx    5b9d1d4 <_gp+0x57841c4>
   c:   2031302e        addi    s1,at,12334
  10:   332e302d        andi    t6,t9,0x302d
  14:   31756275        andi    s5,t3,0x6275
  18:   6e747531        0x6e747531
  1c:   29203130        slti    zero,t1,12592
  20:   2e332e30        sltiu   s3,s1,11824
        ...

Disassembly of section .pdr:

00000000 <.pdr>:
   0:   004006e0        0x4006e0
   4:   c0000000        ll      zero,0(zero)
   8:   fffffffc        0xfffffffc
        ...
  14:   00000020        add     zero,zero,zero
  18:   0000001e        0x1e
  1c:   0000001f        0x1f

Disassembly of section .gnu.attributes:

00000000 <.gnu.attributes>:
   0:   41000000        mftc0   zero,c0_index
   4:   0f676e75        jal     d9db9d4 <_gp+0xd5c29c4>
   8:   00010000        sll     zero,at,0x0
   c:   00070405        0x70405
```

`objdump`的参数有：`-D`：Display assembler contents of all sections，即反汇编所有的节；`-S`：Intermix source code with disassembly，即显示反汇编代码和源代码。

### 2.尝试使用我们编写的 readelf 程序，解析之前在 target 目录下生成的内核 ELF 文 件。 • 也许你会发现我们编写的 readelf 程序是不能解析 readelf 文件本身的，而我们刚 才介绍的系统工具 readelf 则可以解析，这是为什么呢？（提示：尝试使用 readelf -h，并阅读 tools/readelf 目录下的 Makefile，观察 readelf 与 hello 的不同）

执行`./tools/readelf/readelf target/mos`，得到以下结果：

```
0:0x0
1:0x80020000
2:0x80022070
3:0x80022088
4:0x800220a0
5:0x0
6:0x0
7:0x0
8:0x0
9:0x0
10:0x0
11:0x0
12:0x0
13:0x0
14:0x0
15:0x0
16:0x0
17:0x0
```

执行`readelf -h target/mos`得到：

```
ELF 头：
  Magic：   7f 45 4c 46 01 01 01 00 00 00 00 00 00 00 00 00 
  类别:                              ELF32
  数据:                              2 补码，小端序 (little endian)
  Version:                           1 (current)
  OS/ABI:                            UNIX - System V
  ABI 版本:                          0
  类型:                              EXEC (可执行文件)
  系统架构:                          MIPS R3000
  版本:                              0x1
  入口点地址：               0x80021c30
  程序头起点：          52 (bytes into file)
  Start of section headers:          23376 (bytes into file)
  标志：             0x50001001, noreorder, o32, mips32
  Size of this header:               52 (bytes)
  Size of program headers:           32 (bytes)
  Number of program headers:         4
  Size of section headers:           40 (bytes)
  Number of section headers:         18
  Section header string table index: 17
```

执行`readelf -h target/mos`得到：

```
ELF 头：
  Magic：   7f 45 4c 46 02 01 01 00 00 00 00 00 00 00 00 00 
  类别:                              ELF64
  数据:                              2 补码，小端序 (little endian)
  Version:                           1 (current)
  OS/ABI:                            UNIX - System V
  ABI 版本:                          0
  类型:                              DYN (Position-Independent Executable file)
  系统架构:                          Advanced Micro Devices X86-64
  版本:                              0x1
  入口点地址：               0x1180
  程序头起点：          64 (bytes into file)
  Start of section headers:          14488 (bytes into file)
  标志：             0x0
  Size of this header:               64 (bytes)
  Size of program headers:           56 (bytes)
  Number of program headers:         13
  Size of section headers:           64 (bytes)
  Number of section headers:         31
  Section header string table index: 30
```

对比和分析我们的readelf.c代码可知：

我们编写的 readelf 程序不能解析readelf本身的原因是：readelf是ELF64文件，而我们的readelf只能解析ELF32的文件。

### 3.在理论课上我们了解到，MIPS 体系结构上电时，启动入口地址为 0xBFC00000 （其实启动入口地址是根据具体型号而定的，由硬件逻辑确定，也有可能不是这个地址，但 一定是一个确定的地址），但实验操作系统的内核入口并没有放在上电启动地址，而是按照 内存布局图放置。思考为什么这样放置内核还能保证内核入口被正确跳转到？ （提示：思考实验中启动过程的两阶段分别由谁执行。）

实验中操作系统启动分为stage1和stage2两步。

在stage1中，bootloader程序初始化硬件设备，并且为stage2设置RAM，然后将stage2的代码复制到RAM空间，并且设置堆栈，执行stage2.

在stage2中，程序运行在RAM上，且可以执行C语言来实现复杂功能。BIOS 加载 MBR 中的 GRUB 代码后就把CPU交给GRUB，GRUB的工作就是一步一步的加载自身代码，从而识别文件系统，然后就能够将文件系统中的内核镜像文件加载到内核之中。由于整个过程都是在GRUB中完成的，GRUB自然可以设置CPU指令寄存器到正确的内核入口位置。

![启动.png](E:\大学\OS\实验\lab1\实验报告\启动.png)



## 2.难点分析

理解ELF文件的结构，熟悉 ELF 文件头、段头表、节头表等数据结构的含义和如何解析它们；

了解链接器的工作原理，了解操作系统内存布局的概念，包括代码段、数据段、堆栈等的组织方式；

理解启动过程中汇编代码的执行顺序；

入理解可变参数函数的实现原理，以及如何解析格式字符串并将其格式化为实际输出。

## 3.实验体会

通过这次实验，我对于系统启动过程有了更深入的了解，对链接器脚本有了新的认识，对可变参数函数的实现原理进行了学习，并学会如何解析格式字符串并将其转换为实际输出。这些实验任务不仅提高了我的技术能力，还让我更好地理解了操作系统和嵌入式系统的工作原理。我相信这些经验将对我的未来学习OS产生积极的影响。
