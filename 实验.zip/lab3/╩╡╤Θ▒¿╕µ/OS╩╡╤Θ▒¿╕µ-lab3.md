# OS实验报告-lab3

> 学号：22371138
> 
> 姓名：贾锡冰

## 1.思考题

### 1. 请结合 MOS 中的页目录自映射应用解释代码中 e->env_pgdir[PDX(UVPT)] = PADDR(e->env_pgdir) | PTE_V 的含义。

MOS 中的页目录自映射即使一级页表中某一项对应的二级页表为自身。因此这一页表项为自己的物理页号加权限位，即` PADDR(e->env_pgdir) | PTE_V`，由于用户新建进程页表的虚拟地址均从`UVPT`开始，则让`e->env_pgdir[PDX(UVPT)]`等于右侧即可。

### 2. elf_load_seg 以函数指针的形式，接受外部自定义的回调函数 map_page。 请你找到与之相关的 data 这一参数在此处的来源，并思考它的作用。没有这个参数可不可以？为什么？

`elf_load_seg`函数的定义如下：

```c
int elf_load_seg(Elf32_Phdr *ph, const void *bin, elf_mapper_t map_page, void *data)
```

`data`在`elf_load_seg`函数中被传入`map_page`函数：

```c
#38,40
		if ((r = map_page(data, va, offset, perm, bin,
					MIN(bin_size, PAGE_SIZE - offset))) != 0) {
			return r;
#46,48
         if ((r = map_page(data, va + i, 0, perm, bin + i, MIN(bin_size - i, 							PAGE_SIZE))) !=0) {
			return r;
```

由`load_icode`函数中的

```c
panic_on(elf_load_seg(ph, binary + ph->p_offset, load_icode_mapper, e));
```

可知，`data`实际上被传入了`load_icode_mapper`函数，并在

```c
struct Env *env = (struct Env *)data;
```

中被使用。

在C语言中，并没有直接的泛型支持。然而，通过使用函数指针和`void`指针，C语言可以实现一种类似泛型的机制。`data` 参数的使用就是一种类泛型，增加了回调机制的灵活性。不同的调用者可能会使用不同的上下文数据，而这些数据可以通过 `data` 参数传递给回调函数。

此外，过使用 `data` 参数，`elf_load_seg` 函数不需要知道回调函数的内部实现细节，也不需要了解传递给回调函数的具体数据。这有助于保持 `elf_load_seg` 函数的通用性和模块化，降低操作系统的耦合性。

### 3. Thinking 3.3 结合 elf_load_seg 的参数和实现，考虑该函数需要处理哪些页面加载的情况。 

- `va`非页面对齐

  ```c
  if (offset != 0) {
  		if ((r = map_page(data, va, offset, perm, bin,
  				  MIN(bin_size, PAGE_SIZE - offset))) != 0) {
  			return r;
  		}
  	}
  ```

  当地址`va`非页面对齐时，调用`map_page`映射一个页面，将二进制数据填充到从页面对齐地址到段起始地址之间的空隙中。

- 填充剩余的内存空间

  ```c
  while (i < sgsize) {
  		if ((r = map_page(data, va + i, 0, perm, NULL, MIN(sgsize - i, PAGE_SIZE))) != 0) {
  			return r;
  		}
  		i += PAGE_SIZE;
  	}
  ```

  当段的内存大小`sgsize`大于其二进制数据的大小`bin_size`，需要分配额外的页面来填充剩余的空间。

### 4. 这里的 env_tf.cp0_epc 字段指示了进程恢复运行时 PC 应恢复到的位置。我们要运行的进程的代码段预先被载入到了内存中，且程序入口为 e_entry，当我们运行进程时，CPU 将自动从 PC 所指的位置开始执行二进制码。你认为这里的 env_tf.cp0_epc 存储的是物理地址还是虚拟地址?

是虚拟地址。

因为操作系统运行在虚拟内存环境中，CPU看到的地址都是经过内存管理单元（MMU）转换的虚拟地址。

从另一方面看，`ehdr->e_entry`是从ELF文件头中解析出来的，是程序的入口虚拟地址，对于可重定位的目标文件默认是0，而对于可执行文件而言是真实的程序入口，也可以说明`env_tf.cp0_epc`储存的是虚拟地址。

### 5. 试找出 0、1、2、3 号异常处理函数的具体实现位置。

![5](E:\大学\OS\实验\lab3\实验报告\5.png)

- 0号异常：

  ```assembly
  NESTED(handle_int, TF_SIZE, zero)
  	mfc0    t0, CP0_CAUSE
  	mfc0    t2, CP0_STATUS
  	and     t0, t2
  	andi    t1, t0, STATUS_IM7
  	bnez    t1, timer_irq
  timer_irq:
  	li      a0, 0
  	j       schedule
  END(handle_int)
  ```

  在这个宏中，首先取出了`CP0_CAUSE`和`CP0_STATUS`寄存器，然后进行了逻辑与操作，之后将结果加上了`STATUS_IM7`寄存器的值，并根据条件跳转到`schedule`函数。

- 1号异常：

  ```assembly
  BUILD_HANDLER mod do_tlb_mod
  ```

  未直接给出，调用了`do_tlb_mod`函数进行处理。

- 2号异常：

  ```assembly
  BUILD_HANDLER tlb do_tlb_refill
  ```

  未直接给出，调用了`do_tlb_refill`函数进行处理。

- 3号异常：

  同2号异常。

### 6. 阅读 entry.S、genex.S 和 env_asm.S 这几个文件，并尝试说出时钟中断在哪些时候开启，在哪些时候关闭。 

- 在`entry.S`中：

```assembly
exc_gen_entry:
	SAVE_ALL
	/*
	* Note: When EXL is set or UM is unset, the processor is in kernel mode.
	* When EXL is set, the value of EPC is not updated when a new exception occurs.
	* To keep the processor in kernel mode and enable exception reentrancy,
	* we unset UM and EXL, and unset IE to globally disable interrupts.
	*/
	mfc0    t0, CP0_STATUS
	and     t0, t0, ~(STATUS_UM | STATUS_EXL | STATUS_IE)
	mtc0    t0, CP0_STATUS
```

当进行异常分发时，通过`and t0, t0, ~(STATUS_UM | STATUS_EXL | STATUS_IE)`清除了中断使能（IE）位，从而禁用了时钟中断。

- 在`env_asm.S`中：

```assembly
LEAF(env_pop_tf)
.set reorder
.set at
	mtc0    a1, CP0_ENTRYHI
	move    sp, a0
	RESET_KCLOCK
	j       ret_from_exception
END(env_pop_tf)
```

会调用`ret_from_exception`：

```assembly
FEXPORT(ret_from_exception)
	RESTORE_ALL
	eret
```

其中`eret`指令用于中断返回，会返回中断前的状态，若此状态为中断使能状态，则会开启时钟中断。

### 7. 阅读相关代码，思考操作系统是怎么根据时钟中断切换进程的。

```c
void schedule(int yield)
{
	static int count = 0; //当前进程的剩余时间片
	struct Env *e = curenv;// 当前进程
	if (yield || count == 0 || e == NULL || e->env_status != ENV_RUNNABLE)
	{//当时间片耗尽时，执行时钟中断
		if (e != NULL)
		{
			TAILQ_REMOVE(&env_sched_list, e, env_sched_link);
			if(e->env_status == ENV_RUNNABLE)
				TAILQ_INSERT_TAIL(&env_sched_list, e, env_sched_link);
            //将当前进程移至就绪队列尾部
		}
		if (TAILQ_EMPTY(&env_sched_list))
		{
			panic("no runnable env");
		}
		e = TAILQ_FIRST(&env_sched_list);//从就绪队列队首取出一个进程并执行
		count = e->env_pri;//优先级，表示会执行几个时钟周期
	}
	count--;
	env_run(e);
}
```

当一个进程的一个时间片运行结束后，会调用`schedule`函数检查是否需要切换进程。如果一个进程的时间片`count`大于0，且其没有自己调用`yield`产生中断，即可以继续执行。如果一个进程的时间片`count`已耗尽，则会产生时钟中断，将当前进程移至就绪队列尾部，从就绪队列队首取出一个进程并执行，并将`count`设置为这个进程的执行时间片（即优先级）。如此循环往复，可以实现根据时钟中断切换进程。

## 2.难点分析

### 难点一：理解页目录自映射的概念

在MOS中，页目录自映射是一个相对难理解的概念。初次接触时，我花了许多时间来理解其工作原理和目的。页目录自映射实际上是将页目录的某一项映射到它自身，这样做的目的是为了方便地址转换和加快页表访问速度。在实现过程中，需要确保正确设置页目录项，并理解虚拟地址到物理地址的转换过程。

### 难点二：中断处理和进程调度

中断处理和进程调度是操作系统的核心功能之一。在实验过程中，需要我深入理解时钟中断的处理流程，包括中断的触发、保存现场、进程切换和恢复现场等步骤。同时，还需要理解进程调度的策略和实现方式，即基于时间片的轮转调度等。对Exercise 3.12中`schedule`函数的理解花了我很长时间，需要结合代码和理论知识进行深入分析。

## 3.实验体会

在操作系统内核编程中，细节至关重要。一个小小的错误就可能导致系统崩溃或无法正常工作。因此，我在实验过程中始终保持谨慎和细心，充分考虑所有可能的情况，检查我代码逻辑的正确性。如我在完成`schedule`函数时，有以下代码：

```c
		if (e != NULL)
		{
			TAILQ_REMOVE(&env_sched_list, e, env_sched_link);
			if(e->env_status == ENV_RUNNABLE)
				TAILQ_INSERT_TAIL(&env_sched_list, e, env_sched_link);
		}
```

我误写成：

```c
		if (e != NULL && e->env_status == ENV_RUNNABLE)
		{
			TAILQ_REMOVE(&env_sched_list, e, env_sched_link);
			TAILQ_INSERT_TAIL(&env_sched_list, e, env_sched_link);
		}
```

这两段代码看似没有区别，实际上下面的写法可能会导致访问空指针的情况。从这个教训中，我更意识到编写代码时细节的重要性。
