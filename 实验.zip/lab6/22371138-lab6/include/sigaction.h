#ifndef __SIGACTION_H_
#define __SIGACTION_H_
#include <types.h>

#include <trap.h>
#define MAX_SIGACTION 32

#define SIGINT 2
#define SIGILL 4

#define SIG_KILL 9
#define SIG_SEGV 11
#define SIGCHLD 17
#define SIGSYS 31

typedef struct sigset_t {
    uint32_t sig;
} sigset_t;

struct sigaction {
    void     (*sa_handler)(int);
    sigset_t   sa_mask;
};

struct sigaction_queue {
	uint8_t sigState[MAX_SIGACTION];
	uint8_t sigqueue[MAX_SIGACTION];
	uint8_t lpos,rpos,sigPos;
	void (*do_sigaction)(void (*handler)(int),int signum, struct Trapframe* utf,struct Trapframe* ktf);
};

#endif
